
-- Dump of TYPO3 Connection "Default"
-- MariaDB dump 10.19  Distrib 10.5.15-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: db    Database: db
-- ------------------------------------------------------
-- Server version	10.4.26-MariaDB-1:10.4.26+maria~ubu2004-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `backend_layout`
--

DROP TABLE IF EXISTS `backend_layout`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `backend_layout` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `description` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `config` text COLLATE utf8_unicode_ci NOT NULL,
  `icon` text COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `backend_layout`
--

LOCK TABLES `backend_layout` WRITE;
/*!40000 ALTER TABLE `backend_layout` DISABLE KEYS */;
/*!40000 ALTER TABLE `backend_layout` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `be_dashboards`
--

DROP TABLE IF EXISTS `be_dashboards`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `be_dashboards` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `identifier` varchar(120) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `title` varchar(120) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `widgets` text COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `be_dashboards`
--

LOCK TABLES `be_dashboards` WRITE;
/*!40000 ALTER TABLE `be_dashboards` DISABLE KEYS */;
INSERT INTO `be_dashboards` VALUES (1,0,1649317405,1649317405,1,0,0,0,0,'f483d244ab2f4c42ebf0b7a5da9e6e637b9f2531','My dashboard','{\"59c7c8ef9c6c9ba1330111533ade04848c7d9bd6\":{\"identifier\":\"t3information\"},\"5e8f1475c54ac45d894740a220aa3f2c7e3b3949\":{\"identifier\":\"docGettingStarted\"}}');
/*!40000 ALTER TABLE `be_dashboards` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `be_groups`
--

DROP TABLE IF EXISTS `be_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `be_groups` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `description` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `title` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `non_exclude_fields` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `explicit_allowdeny` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `allowed_languages` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `custom_options` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `db_mountpoints` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `pagetypes_select` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `tables_select` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `tables_modify` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `groupMods` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `availableWidgets` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `mfa_providers` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `file_mountpoints` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `file_permissions` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `TSconfig` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `subgroup` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `workspace_perms` smallint(6) NOT NULL DEFAULT 1,
  `category_perms` longtext COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `be_groups`
--

LOCK TABLES `be_groups` WRITE;
/*!40000 ALTER TABLE `be_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `be_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `be_users`
--

DROP TABLE IF EXISTS `be_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `be_users` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `disable` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `description` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `username` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `avatar` int(10) unsigned NOT NULL DEFAULT 0,
  `password` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `admin` smallint(5) unsigned NOT NULL DEFAULT 0,
  `usergroup` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `lang` varchar(10) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'default',
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `db_mountpoints` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `options` smallint(5) unsigned NOT NULL DEFAULT 0,
  `realName` varchar(80) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `userMods` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `allowed_languages` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `uc` mediumblob DEFAULT NULL,
  `file_mountpoints` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `file_permissions` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `workspace_perms` smallint(6) NOT NULL DEFAULT 1,
  `TSconfig` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `lastlogin` int(11) NOT NULL DEFAULT 0,
  `workspace_id` int(11) NOT NULL DEFAULT 0,
  `mfa` mediumblob DEFAULT NULL,
  `category_perms` longtext COLLATE utf8_unicode_ci DEFAULT NULL,
  `password_reset_token` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `username` (`username`),
  KEY `parent` (`pid`,`deleted`,`disable`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `be_users`
--

LOCK TABLES `be_users` WRITE;
/*!40000 ALTER TABLE `be_users` DISABLE KEYS */;
INSERT INTO `be_users` VALUES (1,0,1649317431,1649317388,0,0,0,0,NULL,'admin',0,'$argon2i$v=19$m=65536,t=16,p=1$UXh0Q2pVMU9qclN3NjlDRw$zdJOrxHJdJnGTlBWeoITnyG4mNZnblDwgTjxqlltrgw',1,NULL,'default','',NULL,0,'',NULL,'','a:12:{s:14:\"interfaceSetup\";s:0:\"\";s:10:\"moduleData\";a:14:{s:28:\"dashboard/current_dashboard/\";s:40:\"f483d244ab2f4c42ebf0b7a5da9e6e637b9f2531\";s:8:\"web_list\";a:3:{s:8:\"function\";N;s:8:\"language\";N;s:19:\"constant_editor_cat\";N;}s:10:\"FormEngine\";a:2:{i:0;a:0:{}i:1;s:32:\"9037e102b03b27c69cb65d276eeb5062\";}s:57:\"TYPO3\\CMS\\Backend\\Utility\\BackendUtility::getUpdateSignal\";a:0:{}s:6:\"web_ts\";a:8:{s:8:\"function\";s:85:\"TYPO3\\CMS\\Tstemplate\\Controller\\TypoScriptTemplateInformationModuleFunctionController\";s:8:\"language\";N;s:19:\"constant_editor_cat\";s:11:\"tx_easyconf\";s:15:\"ts_browser_type\";s:5:\"const\";s:16:\"ts_browser_const\";s:1:\"0\";s:23:\"ts_browser_showComments\";s:1:\"1\";s:25:\"tsbrowser_depthKeys_const\";a:6:{s:13:\"easyconf.demo\";i:1;s:10:\"page.theme\";i:1;s:6:\"plugin\";i:1;s:24:\"plugin.bootstrap_package\";i:1;s:33:\"plugin.bootstrap_package.settings\";i:1;s:38:\"plugin.bootstrap_package.settings.scss\";i:1;}s:6:\"action\";s:25:\"web_typoscript_infomodify\";}s:10:\"web_layout\";a:3:{s:8:\"function\";s:1:\"1\";s:8:\"language\";s:1:\"0\";s:19:\"constant_editor_cat\";N;}s:16:\"ExtensionManager\";a:1:{s:6:\"filter\";s:5:\"Local\";}s:47:\"TYPO3\\CMS\\Belog\\Controller\\BackendLogController\";s:337:\"O:39:\"TYPO3\\CMS\\Belog\\Domain\\Model\\Constraint\":11:{s:14:\"\0*\0userOrGroup\";s:1:\"0\";s:9:\"\0*\0number\";i:20;s:15:\"\0*\0workspaceUid\";i:-99;s:10:\"\0*\0channel\";s:3:\"php\";s:8:\"\0*\0level\";s:5:\"debug\";s:17:\"\0*\0startTimestamp\";i:0;s:15:\"\0*\0endTimestamp\";i:0;s:18:\"\0*\0manualDateStart\";N;s:17:\"\0*\0manualDateStop\";N;s:9:\"\0*\0pageId\";i:0;s:8:\"\0*\0depth\";i:0;}\";s:16:\"opendocs::recent\";a:8:{s:32:\"9037e102b03b27c69cb65d276eeb5062\";a:4:{i:0;s:0:\"\";i:1;a:5:{s:4:\"edit\";a:1:{s:25:\"tx_easyconf_configuration\";a:1:{i:9;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:48:\"&edit%5Btx_easyconf_configuration%5D%5B9%5D=edit\";i:3;a:5:{s:5:\"table\";s:25:\"tx_easyconf_configuration\";s:3:\"uid\";i:9;s:3:\"pid\";i:1;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}}s:32:\"c312013d83c1a6ad7fec8b36a37ba3c8\";a:4:{i:0;s:17:\"easyconf dev site\";i:1;a:5:{s:4:\"edit\";a:1:{s:10:\"tt_content\";a:1:{i:1;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:33:\"&edit%5Btt_content%5D%5B1%5D=edit\";i:3;a:5:{s:5:\"table\";s:10:\"tt_content\";s:3:\"uid\";i:1;s:3:\"pid\";i:1;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}}s:32:\"b67df8ed73667684f8bfcd84a0ec41f1\";a:4:{i:0;s:0:\"\";i:1;a:5:{s:4:\"edit\";a:1:{s:25:\"tx_easyconf_configuration\";a:1:{i:10;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:49:\"&edit%5Btx_easyconf_configuration%5D%5B10%5D=edit\";i:3;a:5:{s:5:\"table\";s:25:\"tx_easyconf_configuration\";s:3:\"uid\";i:10;s:3:\"pid\";i:4;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}}s:32:\"10c0adba8cd3d88821ed63ce2cd46027\";a:4:{i:0;s:0:\"\";i:1;a:5:{s:4:\"edit\";a:1:{s:25:\"tx_easyconf_configuration\";a:1:{i:6;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:48:\"&edit%5Btx_easyconf_configuration%5D%5B6%5D=edit\";i:3;a:5:{s:5:\"table\";s:25:\"tx_easyconf_configuration\";s:3:\"uid\";i:6;s:3:\"pid\";i:1;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}}s:32:\"cf4302ec36ed58dc89f38ad1ce8e9369\";a:4:{i:0;s:0:\"\";i:1;a:5:{s:4:\"edit\";a:1:{s:25:\"tx_easyconf_configuration\";a:1:{i:4;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:48:\"&edit%5Btx_easyconf_configuration%5D%5B4%5D=edit\";i:3;a:5:{s:5:\"table\";s:25:\"tx_easyconf_configuration\";s:3:\"uid\";i:4;s:3:\"pid\";i:1;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}}s:32:\"d05de5db7a95716a106a7b65a59bfc32\";a:4:{i:0;s:8:\"NEW SITE\";i:1;a:5:{s:4:\"edit\";a:1:{s:12:\"sys_template\";a:1:{i:1;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";s:9:\"constants\";s:6:\"noView\";N;}i:2;s:57:\"&edit%5Bsys_template%5D%5B1%5D=edit&columnsOnly=constants\";i:3;a:5:{s:5:\"table\";s:12:\"sys_template\";s:3:\"uid\";i:1;s:3:\"pid\";i:1;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}}s:32:\"696addfecc296b326ff6e9f04c7ff3e1\";a:4:{i:0;s:8:\"easyconf\";i:1;a:5:{s:4:\"edit\";a:1:{s:5:\"pages\";a:1:{i:1;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:28:\"&edit%5Bpages%5D%5B1%5D=edit\";i:3;a:5:{s:5:\"table\";s:5:\"pages\";s:3:\"uid\";i:1;s:3:\"pid\";i:0;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}}s:32:\"86205c5935270b8ee413592ec1b62292\";a:4:{i:0;s:8:\"NEW SITE\";i:1;a:5:{s:4:\"edit\";a:1:{s:12:\"sys_template\";a:1:{i:1;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:35:\"&edit%5Bsys_template%5D%5B1%5D=edit\";i:3;a:5:{s:5:\"table\";s:12:\"sys_template\";s:3:\"uid\";i:1;s:3:\"pid\";i:1;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}}}s:13:\"system_config\";a:3:{s:4:\"tree\";s:3:\"tca\";s:11:\"regexSearch\";b:0;s:8:\"node_tca\";a:8:{s:25:\"tx_easyconf_configuration\";i:1;s:33:\"tx_easyconf_configuration.columns\";i:1;s:48:\"tx_easyconf_configuration.columns.agency_company\";i:1;s:60:\"tx_easyconf_configuration.columns.agency_company.tx_easyconf\";i:1;s:49:\"tx_easyconf_configuration.columns.menu_main_style\";i:1;s:61:\"tx_easyconf_configuration.columns.menu_main_style.tx_easyconf\";i:1;s:80:\"tx_easyconf_configuration.columns.admin_easyconf_show_all_properties.tx_easyconf\";i:1;s:75:\"tx_easyconf_configuration.columns.admin_easyconf_show_all_properties.config\";i:1;}}s:12:\"system_dbint\";a:5:{s:8:\"function\";s:8:\"refindex\";s:8:\"language\";N;s:19:\"constant_editor_cat\";N;s:6:\"search\";s:3:\"raw\";s:22:\"search_query_makeQuery\";s:3:\"all\";}s:25:\"web_typoscript_infomodify\";a:1:{s:15:\"templatesOnPage\";i:1;}s:38:\"tools_ExtensionmanagerExtensionmanager\";a:1:{s:6:\"filter\";s:5:\"Local\";}s:28:\"web_typoscript_objectbrowser\";a:9:{s:18:\"sortAlphabetically\";b:1;s:28:\"displayConstantSubstitutions\";b:1;s:15:\"displayComments\";b:1;s:11:\"searchValue\";s:0:\"\";s:23:\"selectedTemplatePerPage\";a:1:{i:1;i:1;}s:18:\"constantConditions\";a:0:{}s:15:\"setupConditions\";a:0:{}s:19:\"constantExpandState\";a:2:{i:0;s:8:\"pizpalue\";i:1;s:15:\"pizpalue.agency\";}s:16:\"setupExpandState\";a:4:{i:0;s:6:\"module\";i:1;s:18:\"module.tx_easyconf\";i:2;s:27:\"module.tx_easyconf.settings\";i:3;s:35:\"module.tx_easyconf.settings.support\";}}}s:14:\"emailMeAtLogin\";i:0;s:8:\"titleLen\";i:50;s:8:\"edit_RTE\";s:1:\"1\";s:20:\"edit_docModuleUpload\";s:1:\"1\";s:25:\"resizeTextareas_MaxHeight\";i:500;s:4:\"lang\";s:7:\"default\";s:19:\"firstLoginTimeStamp\";i:1649317403;s:15:\"moduleSessionID\";a:13:{s:28:\"dashboard/current_dashboard/\";s:40:\"d4c1161ed1096bd64686f049e7ecdcd6d6a4efc2\";s:8:\"web_list\";s:40:\"d4c1161ed1096bd64686f049e7ecdcd6d6a4efc2\";s:10:\"FormEngine\";s:40:\"c56e54652c03bcb960378b74d00fb1667c898175\";s:57:\"TYPO3\\CMS\\Backend\\Utility\\BackendUtility::getUpdateSignal\";s:40:\"c56e54652c03bcb960378b74d00fb1667c898175\";s:6:\"web_ts\";s:40:\"60896541af93c29f1a973730dff3d6e1f39444b8\";s:10:\"web_layout\";s:40:\"6c97f2f0f988f4304c65f58a3374fee3853521e9\";s:16:\"ExtensionManager\";s:40:\"6c97f2f0f988f4304c65f58a3374fee3853521e9\";s:47:\"TYPO3\\CMS\\Belog\\Controller\\BackendLogController\";s:40:\"6c97f2f0f988f4304c65f58a3374fee3853521e9\";s:16:\"opendocs::recent\";s:40:\"c56e54652c03bcb960378b74d00fb1667c898175\";s:12:\"system_dbint\";s:40:\"e7906b8d076a5facd53e58524a231c5f629d2ab5\";s:25:\"web_typoscript_infomodify\";s:40:\"cf9853a154329eca712e77882296ac792a30f102\";s:38:\"tools_ExtensionmanagerExtensionmanager\";s:40:\"cf9853a154329eca712e77882296ac792a30f102\";s:28:\"web_typoscript_objectbrowser\";s:40:\"60896541af93c29f1a973730dff3d6e1f39444b8\";}s:17:\"BackendComponents\";a:1:{s:6:\"States\";a:1:{s:8:\"Pagetree\";a:1:{s:9:\"stateHash\";a:4:{s:3:\"0_0\";s:1:\"1\";s:3:\"0_1\";s:1:\"1\";s:3:\"0_2\";s:1:\"1\";s:3:\"0_3\";s:1:\"1\";}}}}s:17:\"systeminformation\";s:45:\"{\"system_BelogLog\":{\"lastAccess\":1649334562}}\";}',NULL,NULL,1,NULL,1670959261,0,NULL,NULL,''),(2,0,1649317521,1649317521,0,0,0,0,NULL,'_cli_',0,'$argon2i$v=19$m=65536,t=16,p=1$WGloOHc5a2lxaHBHZVBNUw$A2d/hVo9km91FKDziyFGfBPp4Il3EcciSfjaX1rqHbM',1,NULL,'default','',NULL,0,'',NULL,'','a:9:{s:14:\"interfaceSetup\";s:0:\"\";s:10:\"moduleData\";a:0:{}s:14:\"emailMeAtLogin\";i:0;s:8:\"titleLen\";i:50;s:8:\"edit_RTE\";s:1:\"1\";s:20:\"edit_docModuleUpload\";s:1:\"1\";s:25:\"resizeTextareas_MaxHeight\";i:500;s:4:\"lang\";s:7:\"default\";s:19:\"firstLoginTimeStamp\";i:1649317521;}',NULL,NULL,1,NULL,0,0,NULL,NULL,'');
/*!40000 ALTER TABLE `be_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fe_groups`
--

DROP TABLE IF EXISTS `fe_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fe_groups` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `description` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `tx_extbase_type` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  `title` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `subgroup` tinytext COLLATE utf8_unicode_ci DEFAULT NULL,
  `TSconfig` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `felogin_redirectPid` tinytext COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fe_groups`
--

LOCK TABLES `fe_groups` WRITE;
/*!40000 ALTER TABLE `fe_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `fe_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fe_users`
--

DROP TABLE IF EXISTS `fe_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fe_users` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `disable` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `description` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `tx_extbase_type` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  `username` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `password` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `usergroup` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `name` varchar(160) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `first_name` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `middle_name` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `last_name` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `address` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `telephone` varchar(30) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `fax` varchar(30) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `uc` blob DEFAULT NULL,
  `title` varchar(40) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `zip` varchar(10) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `city` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `country` varchar(40) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `www` varchar(80) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `company` varchar(80) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `image` tinytext COLLATE utf8_unicode_ci DEFAULT NULL,
  `TSconfig` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `lastlogin` int(11) NOT NULL DEFAULT 0,
  `is_online` int(10) unsigned NOT NULL DEFAULT 0,
  `mfa` mediumblob DEFAULT NULL,
  `felogin_redirectPid` tinytext COLLATE utf8_unicode_ci DEFAULT NULL,
  `felogin_forgotHash` varchar(80) COLLATE utf8_unicode_ci DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`username`(100)),
  KEY `username` (`username`(100)),
  KEY `is_online` (`is_online`),
  KEY `felogin_forgotHash` (`felogin_forgotHash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fe_users`
--

LOCK TABLES `fe_users` WRITE;
/*!40000 ALTER TABLE `fe_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `fe_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pages`
--

DROP TABLE IF EXISTS `pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pages` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `fe_group` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `rowDescription` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `editlock` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_source` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `perms_userid` int(10) unsigned NOT NULL DEFAULT 0,
  `perms_groupid` int(10) unsigned NOT NULL DEFAULT 0,
  `perms_user` smallint(5) unsigned NOT NULL DEFAULT 0,
  `perms_group` smallint(5) unsigned NOT NULL DEFAULT 0,
  `perms_everybody` smallint(5) unsigned NOT NULL DEFAULT 0,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `slug` varchar(2048) COLLATE utf8_unicode_ci DEFAULT NULL,
  `doktype` int(10) unsigned NOT NULL DEFAULT 0,
  `TSconfig` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_siteroot` smallint(6) NOT NULL DEFAULT 0,
  `php_tree_stop` smallint(6) NOT NULL DEFAULT 0,
  `url` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `shortcut` int(10) unsigned NOT NULL DEFAULT 0,
  `shortcut_mode` int(10) unsigned NOT NULL DEFAULT 0,
  `subtitle` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `layout` int(10) unsigned NOT NULL DEFAULT 0,
  `target` varchar(80) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `media` int(10) unsigned NOT NULL DEFAULT 0,
  `lastUpdated` int(11) NOT NULL DEFAULT 0,
  `keywords` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `cache_timeout` int(10) unsigned NOT NULL DEFAULT 0,
  `cache_tags` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `newUntil` int(11) NOT NULL DEFAULT 0,
  `description` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `no_search` smallint(5) unsigned NOT NULL DEFAULT 0,
  `SYS_LASTCHANGED` int(10) unsigned NOT NULL DEFAULT 0,
  `abstract` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `module` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `extendToSubpages` smallint(5) unsigned NOT NULL DEFAULT 0,
  `author` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `author_email` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `nav_title` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `nav_hide` smallint(6) NOT NULL DEFAULT 0,
  `content_from_pid` int(10) unsigned NOT NULL DEFAULT 0,
  `mount_pid` int(10) unsigned NOT NULL DEFAULT 0,
  `mount_pid_ol` smallint(6) NOT NULL DEFAULT 0,
  `l18n_cfg` smallint(6) NOT NULL DEFAULT 0,
  `backend_layout` varchar(64) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `backend_layout_next_level` varchar(64) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `tsconfig_includes` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `categories` int(10) unsigned NOT NULL DEFAULT 0,
  `tx_impexp_origuid` int(11) NOT NULL DEFAULT 0,
  `seo_title` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `no_index` smallint(6) NOT NULL DEFAULT 0,
  `no_follow` smallint(6) NOT NULL DEFAULT 0,
  `og_title` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `og_description` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `og_image` int(10) unsigned NOT NULL DEFAULT 0,
  `twitter_title` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `twitter_description` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `twitter_image` int(10) unsigned NOT NULL DEFAULT 0,
  `twitter_card` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `canonical_link` varchar(2048) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `sitemap_priority` decimal(2,1) NOT NULL DEFAULT 0.5,
  `sitemap_changefreq` varchar(10) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `nav_icon_set` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `nav_icon_identifier` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `nav_icon` int(10) unsigned DEFAULT 0,
  `thumbnail` int(10) unsigned DEFAULT 0,
  `tx_pizpalue_background_image` int(10) unsigned DEFAULT 0,
  `tx_pizpalue_css` text COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `determineSiteRoot` (`is_siteroot`),
  KEY `language_identifier` (`l10n_parent`,`sys_language_uid`),
  KEY `slug` (`slug`(127)),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `translation_source` (`l10n_source`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pages`
--

LOCK TABLES `pages` WRITE;
/*!40000 ALTER TABLE `pages` DISABLE KEYS */;
INSERT INTO `pages` VALUES (1,0,1649335015,1649334337,0,0,0,0,'',256,NULL,0,0,0,0,NULL,0,'{\"doktype\":\"\",\"title\":\"\",\"slug\":\"\",\"nav_title\":\"\",\"subtitle\":\"\",\"nav_icon_set\":\"\",\"nav_icon\":\"\",\"seo_title\":\"\",\"description\":\"\",\"no_index\":\"\",\"no_follow\":\"\",\"canonical_link\":\"\",\"sitemap_changefreq\":\"\",\"sitemap_priority\":\"\",\"og_title\":\"\",\"og_description\":\"\",\"og_image\":\"\",\"twitter_title\":\"\",\"twitter_description\":\"\",\"twitter_image\":\"\",\"twitter_card\":\"\",\"abstract\":\"\",\"keywords\":\"\",\"author\":\"\",\"author_email\":\"\",\"lastUpdated\":\"\",\"layout\":\"\",\"newUntil\":\"\",\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"tx_pizpalue_background_image\":\"\",\"thumbnail\":\"\",\"content_from_pid\":\"\",\"target\":\"\",\"cache_timeout\":\"\",\"cache_tags\":\"\",\"is_siteroot\":\"\",\"no_search\":\"\",\"php_tree_stop\":\"\",\"module\":\"\",\"media\":\"\",\"tsconfig_includes\":\"\",\"TSconfig\":\"\",\"l18n_cfg\":\"\",\"hidden\":\"\",\"nav_hide\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"extendToSubpages\":\"\",\"fe_group\":\"\",\"fe_login_mode\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,1,1,31,31,0,'easyconf','/',1,NULL,1,0,'',0,0,'',0,'',0,0,NULL,0,'',0,NULL,0,1649335015,NULL,'',0,'','','',0,0,0,0,0,'pagets__simple','',NULL,0,0,'',0,0,'',NULL,0,'',NULL,0,'summary','',0.5,'','','',0,0,0,NULL),(2,1,1649338691,1649338672,0,0,0,0,'0',256,NULL,0,0,0,0,NULL,0,'{\"hidden\":\"\"}',0,0,0,0,1,1,31,31,0,'Page with template','/page-with-template',1,NULL,0,0,'',0,0,'',0,'',0,0,NULL,0,'',0,NULL,0,0,NULL,'',0,'','','',0,0,0,0,0,'','',NULL,0,0,'',0,0,'',NULL,0,'',NULL,0,'summary','',0.5,'','','',0,0,0,NULL),(3,1,1649338710,1649338706,0,0,0,0,'0',512,NULL,0,0,0,0,NULL,0,'{\"hidden\":\"\"}',0,0,0,0,1,1,31,31,0,'Page without template','/page-without-template',1,NULL,0,0,'',0,0,'',0,'',0,0,NULL,0,'',0,NULL,0,0,NULL,'',0,'','','',0,0,0,0,0,'','',NULL,0,0,'',0,0,'',NULL,0,'',NULL,0,'summary','',0.5,'','','',0,0,0,NULL),(4,2,1649919224,1649919221,0,0,0,0,'0',256,NULL,0,0,0,0,NULL,0,'{\"hidden\":\"\"}',0,0,0,0,1,1,31,31,0,'Subpage with template','/page-with-template/subpage-with-template',1,NULL,0,0,'',0,0,'',0,'',0,0,NULL,0,'',0,NULL,0,0,NULL,'',0,'','','',0,0,0,0,0,'','',NULL,0,0,'',0,0,'',NULL,0,'',NULL,0,'summary','',0.5,'','','',0,0,0,NULL),(5,3,1649919330,1649919326,0,0,0,0,'0',256,NULL,0,0,0,0,NULL,0,'{\"hidden\":\"\"}',0,0,0,0,1,1,31,31,0,'Subpage with template','/page-without-template/subpage-with-template',1,NULL,0,0,'',0,0,'',0,'',0,0,NULL,0,'',0,NULL,0,0,NULL,'',0,'','','',0,0,0,0,0,'','',NULL,0,0,'',0,0,'',NULL,0,'',NULL,0,'summary','',0.5,'','','',0,0,0,NULL);
/*!40000 ALTER TABLE `pages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_be_shortcuts`
--

DROP TABLE IF EXISTS `sys_be_shortcuts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_be_shortcuts` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `userid` int(10) unsigned NOT NULL DEFAULT 0,
  `route` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `arguments` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `sc_group` smallint(6) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `event` (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_be_shortcuts`
--

LOCK TABLES `sys_be_shortcuts` WRITE;
/*!40000 ALTER TABLE `sys_be_shortcuts` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_be_shortcuts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_category`
--

DROP TABLE IF EXISTS `sys_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_category` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `description` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `title` tinytext COLLATE utf8_unicode_ci NOT NULL,
  `items` int(11) NOT NULL DEFAULT 0,
  `parent` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `category_parent` (`parent`),
  KEY `category_list` (`pid`,`deleted`,`sys_language_uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_category`
--

LOCK TABLES `sys_category` WRITE;
/*!40000 ALTER TABLE `sys_category` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_category_record_mm`
--

DROP TABLE IF EXISTS `sys_category_record_mm`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_category_record_mm` (
  `uid_local` int(10) unsigned NOT NULL DEFAULT 0,
  `uid_foreign` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting_foreign` int(10) unsigned NOT NULL DEFAULT 0,
  `tablenames` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `fieldname` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  KEY `uid_local` (`uid_local`),
  KEY `uid_foreign` (`uid_foreign`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_category_record_mm`
--

LOCK TABLES `sys_category_record_mm` WRITE;
/*!40000 ALTER TABLE `sys_category_record_mm` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_category_record_mm` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_file`
--

DROP TABLE IF EXISTS `sys_file`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_file` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `last_indexed` int(11) NOT NULL DEFAULT 0,
  `missing` smallint(6) NOT NULL DEFAULT 0,
  `storage` int(11) NOT NULL DEFAULT 0,
  `type` varchar(10) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `metadata` int(11) NOT NULL DEFAULT 0,
  `identifier` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `identifier_hash` varchar(40) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `folder_hash` varchar(40) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `extension` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `mime_type` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `name` tinytext COLLATE utf8_unicode_ci DEFAULT NULL,
  `sha1` varchar(40) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `size` bigint(20) unsigned NOT NULL DEFAULT 0,
  `creation_date` int(11) NOT NULL DEFAULT 0,
  `modification_date` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `sel01` (`storage`,`identifier_hash`),
  KEY `folder` (`storage`,`folder_hash`),
  KEY `tstamp` (`tstamp`),
  KEY `lastindex` (`last_indexed`),
  KEY `sha1` (`sha1`),
  KEY `parent` (`pid`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file`
--

LOCK TABLES `sys_file` WRITE;
/*!40000 ALTER TABLE `sys_file` DISABLE KEYS */;
INSERT INTO `sys_file` VALUES (1,0,1649334988,0,0,0,'2',0,'/typo3conf/ext/pizpalue/Resources/Public/Images/logo.svg','f58aecbf54576a74b25ac2b41de7ea67ab111985','dd94046bf22bb2ceaab9445e61808b94503ecba0','svg','image/svg+xml','logo.svg','209bad3465fb3ea3045e14b4fb46648e4fa669f0',6428,1649058661,1648458274),(2,0,1649334988,0,0,0,'2',0,'/typo3conf/ext/pizpalue/Resources/Public/Images/logo_inv.svg','6f173dfaa393763e1afe9baeac4ec8fcd222f105','dd94046bf22bb2ceaab9445e61808b94503ecba0','svg','image/svg+xml','logo_inv.svg','6fb1dcf4ee8443902d186f5960437bd32356e5c6',6426,1649058661,1648458274),(3,0,1670959331,0,0,0,'2',0,'/_assets/e1c6bf1513db4b2f5d552affd7e6d5f6/Images/BootstrapPackage.svg','d5efb7b75b57ab260b2114391f95903bf8b78253','23eb7debc368d56b875e463d3405759411a5edf6','svg','image/svg+xml','BootstrapPackage.svg','a6fb0cc7b50579d6255f16171147695a55b93c27',3843,1670871175,1670331676),(4,0,1670959331,0,0,0,'2',0,'/_assets/e1c6bf1513db4b2f5d552affd7e6d5f6/Images/BootstrapPackageInverted.svg','8384d8d99b755cc4a3df94648118b94c8642a950','23eb7debc368d56b875e463d3405759411a5edf6','svg','image/svg+xml','BootstrapPackageInverted.svg','493f5cd69ede03cf7d436e92481422145674b907',3784,1670871175,1670331676);
/*!40000 ALTER TABLE `sys_file` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_file_collection`
--

DROP TABLE IF EXISTS `sys_file_collection`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_file_collection` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `description` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `title` tinytext COLLATE utf8_unicode_ci DEFAULT NULL,
  `type` varchar(30) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'static',
  `files` int(11) NOT NULL DEFAULT 0,
  `storage` int(11) NOT NULL DEFAULT 0,
  `folder` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `recursive` smallint(6) NOT NULL DEFAULT 0,
  `category` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_collection`
--

LOCK TABLES `sys_file_collection` WRITE;
/*!40000 ALTER TABLE `sys_file_collection` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_file_collection` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_file_metadata`
--

DROP TABLE IF EXISTS `sys_file_metadata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_file_metadata` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `file` int(11) NOT NULL DEFAULT 0,
  `title` tinytext COLLATE utf8_unicode_ci DEFAULT NULL,
  `width` int(11) NOT NULL DEFAULT 0,
  `height` int(11) NOT NULL DEFAULT 0,
  `description` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `alternative` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `categories` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `file` (`file`),
  KEY `fal_filelist` (`l10n_parent`,`sys_language_uid`),
  KEY `parent` (`pid`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_metadata`
--

LOCK TABLES `sys_file_metadata` WRITE;
/*!40000 ALTER TABLE `sys_file_metadata` DISABLE KEYS */;
INSERT INTO `sys_file_metadata` VALUES (1,0,1649334988,1649334988,0,0,NULL,0,'',0,0,0,0,1,NULL,1773,600,NULL,NULL,0),(2,0,1649334988,1649334988,0,0,NULL,0,'',0,0,0,0,2,NULL,1773,600,NULL,NULL,0),(3,0,1670959330,1670959330,0,0,NULL,0,'',0,0,0,0,3,NULL,244,68,NULL,NULL,0),(4,0,1670959330,1670959330,0,0,NULL,0,'',0,0,0,0,4,NULL,244,68,NULL,NULL,0);
/*!40000 ALTER TABLE `sys_file_metadata` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_file_processedfile`
--

DROP TABLE IF EXISTS `sys_file_processedfile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_file_processedfile` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `tstamp` int(11) NOT NULL DEFAULT 0,
  `crdate` int(11) NOT NULL DEFAULT 0,
  `storage` int(11) NOT NULL DEFAULT 0,
  `original` int(11) NOT NULL DEFAULT 0,
  `identifier` varchar(512) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `name` tinytext COLLATE utf8_unicode_ci DEFAULT NULL,
  `processing_url` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `configuration` blob DEFAULT NULL,
  `configurationsha1` varchar(40) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `originalfilesha1` varchar(40) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `task_type` varchar(200) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `checksum` varchar(32) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `width` int(11) DEFAULT 0,
  `height` int(11) DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `combined_1` (`original`,`task_type`(100),`configurationsha1`),
  KEY `identifier` (`storage`,`identifier`(180))
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_processedfile`
--

LOCK TABLES `sys_file_processedfile` WRITE;
/*!40000 ALTER TABLE `sys_file_processedfile` DISABLE KEYS */;
INSERT INTO `sys_file_processedfile` VALUES (1,1649334988,1649334988,0,1,'',NULL,'','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','24f48d5b4de7d99b7144e6559156976855e74b5d','209bad3465fb3ea3045e14b4fb46648e4fa669f0','Image.CropScaleMask','c854d883db',1773,600),(2,1649334988,1649334988,0,2,'',NULL,'','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','24f48d5b4de7d99b7144e6559156976855e74b5d','6fb1dcf4ee8443902d186f5960437bd32356e5c6','Image.CropScaleMask','620f205897',1773,600),(3,1670959331,1670959331,0,3,'',NULL,'','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','24f48d5b4de7d99b7144e6559156976855e74b5d','a6fb0cc7b50579d6255f16171147695a55b93c27','Image.CropScaleMask','8188a986c7',244,68),(4,1670959331,1670959331,0,4,'',NULL,'','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','24f48d5b4de7d99b7144e6559156976855e74b5d','493f5cd69ede03cf7d436e92481422145674b907','Image.CropScaleMask','af2f219fb0',244,68);
/*!40000 ALTER TABLE `sys_file_processedfile` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_file_reference`
--

DROP TABLE IF EXISTS `sys_file_reference`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_file_reference` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `uid_local` int(11) NOT NULL DEFAULT 0,
  `uid_foreign` int(11) NOT NULL DEFAULT 0,
  `tablenames` varchar(64) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `fieldname` varchar(64) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `sorting_foreign` int(11) NOT NULL DEFAULT 0,
  `title` tinytext COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `alternative` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `link` varchar(1024) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `crop` varchar(4000) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `autoplay` smallint(6) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `tablenames_fieldname` (`tablenames`(32),`fieldname`(12)),
  KEY `deleted` (`deleted`),
  KEY `uid_local` (`uid_local`),
  KEY `uid_foreign` (`uid_foreign`),
  KEY `combined_1` (`l10n_parent`,`t3ver_oid`,`t3ver_wsid`,`t3ver_state`,`deleted`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_reference`
--

LOCK TABLES `sys_file_reference` WRITE;
/*!40000 ALTER TABLE `sys_file_reference` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_file_reference` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_file_storage`
--

DROP TABLE IF EXISTS `sys_file_storage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_file_storage` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `description` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `driver` tinytext COLLATE utf8_unicode_ci DEFAULT NULL,
  `configuration` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_default` smallint(6) NOT NULL DEFAULT 0,
  `is_browsable` smallint(6) NOT NULL DEFAULT 0,
  `is_public` smallint(6) NOT NULL DEFAULT 0,
  `is_writable` smallint(6) NOT NULL DEFAULT 0,
  `is_online` smallint(6) NOT NULL DEFAULT 1,
  `auto_extract_metadata` smallint(6) NOT NULL DEFAULT 1,
  `processingfolder` tinytext COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_storage`
--

LOCK TABLES `sys_file_storage` WRITE;
/*!40000 ALTER TABLE `sys_file_storage` DISABLE KEYS */;
INSERT INTO `sys_file_storage` VALUES (1,0,1649317415,1649317415,0,'This is the local fileadmin/ directory. This storage mount has been created automatically by TYPO3.','fileadmin','Local','<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"sDEF\">\n            <language index=\"lDEF\">\n                <field index=\"basePath\">\n                    <value index=\"vDEF\">fileadmin/</value>\n                </field>\n                <field index=\"pathType\">\n                    <value index=\"vDEF\">relative</value>\n                </field>\n                <field index=\"caseSensitive\">\n                    <value index=\"vDEF\">1</value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>',1,1,1,1,1,1,NULL);
/*!40000 ALTER TABLE `sys_file_storage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_filemounts`
--

DROP TABLE IF EXISTS `sys_filemounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_filemounts` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `description` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `read_only` smallint(5) unsigned NOT NULL DEFAULT 0,
  `identifier` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_filemounts`
--

LOCK TABLES `sys_filemounts` WRITE;
/*!40000 ALTER TABLE `sys_filemounts` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_filemounts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_history`
--

DROP TABLE IF EXISTS `sys_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_history` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `actiontype` smallint(6) NOT NULL DEFAULT 0,
  `usertype` varchar(2) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'BE',
  `userid` int(10) unsigned DEFAULT NULL,
  `originaluserid` int(10) unsigned DEFAULT NULL,
  `recuid` int(11) NOT NULL DEFAULT 0,
  `tablename` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `history_data` mediumtext COLLATE utf8_unicode_ci DEFAULT NULL,
  `workspace` int(11) DEFAULT 0,
  `correlation_id` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `recordident_1` (`tablename`(100),`recuid`),
  KEY `recordident_2` (`tablename`(100),`tstamp`)
) ENGINE=InnoDB AUTO_INCREMENT=76 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_history`
--

LOCK TABLES `sys_history` WRITE;
/*!40000 ALTER TABLE `sys_history` DISABLE KEYS */;
INSERT INTO `sys_history` VALUES (1,1649317431,2,'BE',1,0,1,'be_users','{\"oldRecord\":{\"password\":\"$argon2i$v=19$m=65536,t=16,p=1$WW9rRUZvVlhKdkMuSDg0Zg$XnM+mQ0n8ON9VB7eQWi4W7UOg53tuDRBbEUmF6sStPQ\"},\"newRecord\":{\"password\":\"$argon2i$v=19$m=65536,t=16,p=1$UXh0Q2pVMU9qclN3NjlDRw$zdJOrxHJdJnGTlBWeoITnyG4mNZnblDwgTjxqlltrgw\"}}',0,'0400$33628e4f252161bbfa018bb930cad933:084907bc914ff27cf2301aec50eb66b2'),(2,1649334337,1,'BE',1,0,1,'pages','{\"uid\":1,\"pid\":0,\"tstamp\":1649334337,\"crdate\":1649334337,\"cruser_id\":1,\"deleted\":0,\"hidden\":1,\"starttime\":0,\"endtime\":0,\"fe_group\":\"0\",\"sorting\":256,\"rowDescription\":null,\"editlock\":0,\"sys_language_uid\":0,\"l10n_parent\":0,\"l10n_source\":0,\"l10n_state\":null,\"t3_origuid\":0,\"l10n_diffsource\":\"\",\"t3ver_oid\":0,\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"perms_userid\":1,\"perms_groupid\":1,\"perms_user\":31,\"perms_group\":31,\"perms_everybody\":0,\"title\":\"easyconf\",\"slug\":\"\\/\",\"doktype\":1,\"TSconfig\":null,\"is_siteroot\":0,\"php_tree_stop\":0,\"url\":\"\",\"shortcut\":0,\"shortcut_mode\":0,\"subtitle\":\"\",\"layout\":0,\"target\":\"\",\"media\":0,\"lastUpdated\":0,\"keywords\":null,\"cache_timeout\":0,\"cache_tags\":\"\",\"newUntil\":0,\"description\":null,\"no_search\":0,\"SYS_LASTCHANGED\":0,\"abstract\":null,\"module\":\"\",\"extendToSubpages\":0,\"author\":\"\",\"author_email\":\"\",\"nav_title\":\"\",\"nav_hide\":0,\"content_from_pid\":0,\"mount_pid\":0,\"mount_pid_ol\":0,\"l18n_cfg\":0,\"fe_login_mode\":0,\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"tsconfig_includes\":null,\"categories\":0,\"tx_impexp_origuid\":0,\"seo_title\":\"\",\"no_index\":0,\"no_follow\":0,\"og_title\":\"\",\"og_description\":null,\"og_image\":0,\"twitter_title\":\"\",\"twitter_description\":null,\"twitter_image\":0,\"twitter_card\":\"summary\",\"canonical_link\":\"\",\"sitemap_priority\":\"0.5\",\"sitemap_changefreq\":\"\",\"nav_icon_set\":\"\",\"nav_icon_identifier\":\"\",\"nav_icon\":0,\"thumbnail\":0,\"tx_pizpalue_background_image\":0}',0,'0400$97f8d2c8c5d410e7277b6b31756775c0:e175f7045d7ccbfb26ffcf279422c2e5'),(3,1649334341,2,'BE',1,0,1,'pages','{\"oldRecord\":{\"hidden\":1,\"l10n_diffsource\":\"\"},\"newRecord\":{\"hidden\":\"0\",\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$c80e0c1375ac01c8a71c976c5143839f:e175f7045d7ccbfb26ffcf279422c2e5'),(4,1649334923,2,'BE',1,0,1,'pages','{\"oldRecord\":{\"is_siteroot\":0,\"fe_group\":\"0\",\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"},\"newRecord\":{\"is_siteroot\":\"1\",\"fe_group\":\"\",\"l10n_diffsource\":\"{\\\"doktype\\\":\\\"\\\",\\\"title\\\":\\\"\\\",\\\"slug\\\":\\\"\\\",\\\"nav_title\\\":\\\"\\\",\\\"subtitle\\\":\\\"\\\",\\\"nav_icon_set\\\":\\\"\\\",\\\"nav_icon\\\":\\\"\\\",\\\"seo_title\\\":\\\"\\\",\\\"description\\\":\\\"\\\",\\\"no_index\\\":\\\"\\\",\\\"no_follow\\\":\\\"\\\",\\\"canonical_link\\\":\\\"\\\",\\\"sitemap_changefreq\\\":\\\"\\\",\\\"sitemap_priority\\\":\\\"\\\",\\\"og_title\\\":\\\"\\\",\\\"og_description\\\":\\\"\\\",\\\"og_image\\\":\\\"\\\",\\\"twitter_title\\\":\\\"\\\",\\\"twitter_description\\\":\\\"\\\",\\\"twitter_image\\\":\\\"\\\",\\\"twitter_card\\\":\\\"\\\",\\\"abstract\\\":\\\"\\\",\\\"keywords\\\":\\\"\\\",\\\"author\\\":\\\"\\\",\\\"author_email\\\":\\\"\\\",\\\"lastUpdated\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"newUntil\\\":\\\"\\\",\\\"backend_layout\\\":\\\"\\\",\\\"backend_layout_next_level\\\":\\\"\\\",\\\"tx_pizpalue_background_image\\\":\\\"\\\",\\\"thumbnail\\\":\\\"\\\",\\\"content_from_pid\\\":\\\"\\\",\\\"target\\\":\\\"\\\",\\\"cache_timeout\\\":\\\"\\\",\\\"cache_tags\\\":\\\"\\\",\\\"is_siteroot\\\":\\\"\\\",\\\"no_search\\\":\\\"\\\",\\\"php_tree_stop\\\":\\\"\\\",\\\"module\\\":\\\"\\\",\\\"media\\\":\\\"\\\",\\\"tsconfig_includes\\\":\\\"\\\",\\\"TSconfig\\\":\\\"\\\",\\\"l18n_cfg\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"nav_hide\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"extendToSubpages\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"fe_login_mode\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\"}\"}}',0,'0400$5bc1d7b8b9647cd2bbe81e3c447e6624:e175f7045d7ccbfb26ffcf279422c2e5'),(5,1649334946,1,'BE',1,0,1,'sys_template','{\"uid\":1,\"pid\":1,\"tstamp\":1649334946,\"crdate\":1649334946,\"cruser_id\":1,\"deleted\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"sorting\":256,\"description\":null,\"t3_origuid\":0,\"t3ver_oid\":0,\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"title\":\"NEW SITE\",\"root\":1,\"clear\":3,\"include_static_file\":null,\"constants\":null,\"config\":\"\\n# Default PAGE object:\\npage = PAGE\\npage.10 = TEXT\\npage.10.value = HELLO WORLD!\\n\",\"basedOn\":\"\",\"includeStaticAfterBasedOn\":0,\"static_file_mode\":0,\"tx_impexp_origuid\":0}',0,'0400$8318ccd71e349100f28dab5909d4e9c2:35af6288617af54964e77af08c30949a'),(6,1649334958,2,'BE',1,0,1,'sys_template','{\"oldRecord\":{\"config\":\"\\n# Default PAGE object:\\npage = PAGE\\npage.10 = TEXT\\npage.10.value = HELLO WORLD!\\n\"},\"newRecord\":{\"config\":\"\\r\\n\"}}',0,'0400$9360335c4117441843c41250820d660f:35af6288617af54964e77af08c30949a'),(7,1649334980,2,'BE',1,0,1,'sys_template','{\"oldRecord\":{\"config\":\"\\r\\n\",\"include_static_file\":null},\"newRecord\":{\"config\":\"\",\"include_static_file\":\"EXT:bootstrap_package\\/Configuration\\/TypoScript,EXT:pizpalue\\/Configuration\\/TypoScript\\/Main\"}}',0,'0400$2cf368f65fb5b2f3818d4b271b7dcca2:35af6288617af54964e77af08c30949a'),(8,1649335015,2,'BE',1,0,1,'pages','{\"oldRecord\":{\"backend_layout\":\"\"},\"newRecord\":{\"backend_layout\":\"pagets__simple\"}}',0,'0400$b898b4536801814e2e05156ccd8f429f:e175f7045d7ccbfb26ffcf279422c2e5'),(9,1649335052,1,'BE',1,0,1,'tt_content','{\"uid\":1,\"rowDescription\":\"\",\"pid\":1,\"tstamp\":1649335052,\"crdate\":1649335052,\"cruser_id\":1,\"deleted\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"fe_group\":\"\",\"sorting\":256,\"editlock\":0,\"sys_language_uid\":0,\"l18n_parent\":0,\"l10n_source\":0,\"l10n_state\":null,\"t3_origuid\":0,\"l18n_diffsource\":\"\",\"t3ver_oid\":0,\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"CType\":\"header\",\"header\":\"easyconf dev site\",\"header_position\":\"center\",\"bodytext\":null,\"bullets_type\":0,\"uploads_description\":0,\"uploads_type\":0,\"assets\":0,\"image\":0,\"imagewidth\":0,\"imageorient\":0,\"imagecols\":1,\"imageborder\":0,\"media\":0,\"layout\":\"0\",\"frame_class\":\"default\",\"cols\":0,\"space_before_class\":\"\",\"space_after_class\":\"\",\"records\":null,\"pages\":null,\"colPos\":0,\"subheader\":\"\",\"header_link\":\"\",\"image_zoom\":0,\"header_layout\":\"1\",\"list_type\":\"\",\"sectionIndex\":1,\"linkToTop\":0,\"file_collections\":null,\"filelink_size\":0,\"filelink_sorting\":\"\",\"filelink_sorting_direction\":\"\",\"target\":\"\",\"date\":0,\"recursive\":0,\"imageheight\":0,\"pi_flexform\":null,\"accessibility_title\":\"\",\"accessibility_bypass\":0,\"accessibility_bypass_text\":\"\",\"category_field\":\"\",\"table_class\":\"\",\"table_caption\":null,\"table_delimiter\":124,\"table_enclosure\":0,\"table_header_position\":0,\"table_tfoot\":0,\"categories\":0,\"selected_categories\":null,\"tx_impexp_origuid\":0,\"teaser\":null,\"aspect_ratio\":\"1.3333333333333\",\"items_per_page\":10,\"readmore_label\":\"\",\"quote_source\":\"\",\"quote_link\":\"\",\"panel_class\":\"default\",\"file_folder\":null,\"icon\":\"\",\"icon_set\":\"\",\"icon_file\":0,\"icon_position\":\"\",\"icon_size\":\"default\",\"icon_type\":\"default\",\"icon_color\":\"#FFFFFF\",\"icon_background\":\"#333333\",\"external_media_source\":\"\",\"external_media_ratio\":\"\",\"tx_bootstrappackage_card_group_item\":0,\"tx_bootstrappackage_carousel_item\":0,\"tx_bootstrappackage_accordion_item\":0,\"tx_bootstrappackage_icon_group_item\":0,\"tx_bootstrappackage_tab_item\":0,\"tx_bootstrappackage_timeline_item\":0,\"frame_layout\":\"default\",\"background_color_class\":\"primary\",\"background_image\":0,\"background_image_options\":\"<?xml version=\\\"1.0\\\" encoding=\\\"utf-8\\\" standalone=\\\"yes\\\" ?>\\n<T3FlexForms>\\n    <data>\\n        <sheet index=\\\"sDEF\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"parallax\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n                <field index=\\\"fade\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n                <field index=\\\"filter\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n    <\\/data>\\n<\\/T3FlexForms>\",\"tx_pizpalue_header_class\":\"none\",\"tx_pizpalue_subheader_class\":\"none\",\"tx_pizpalue_layout_breakpoint\":\"\",\"tx_pizpalue_classes\":\"\",\"tx_pizpalue_style\":\"\",\"tx_pizpalue_attributes\":\"\",\"tx_pizpalue_animation\":\"0\",\"tx_pizpalue_image_variants\":\"variants\",\"tx_pizpalue_background_image_variants\":\"pageVariants\",\"tx_pizpalue_image_scaling\":\"xxl: 1.0,\\nxl: 1.0,\\nlg: 1.0,\\nmd: 1.0,\\nsm: 1.0,\\nxs: 1.0\",\"tx_pizpalue_image_aspect_ratio\":\"xxl: 0,\\nxl: 0,\\nlg: 0,\\nmd: 0,\\nsm: 0,\\nxs: 0\"}',0,'0400$06ab9e6fc205cb02c360300e8b048dac:7fa2c035f26826fe83eeecaaeddc4d40'),(10,1649338672,1,'BE',1,0,2,'pages','{\"uid\":2,\"pid\":1,\"tstamp\":1649338672,\"crdate\":1649338672,\"cruser_id\":1,\"deleted\":0,\"hidden\":1,\"starttime\":0,\"endtime\":0,\"fe_group\":\"0\",\"sorting\":256,\"rowDescription\":null,\"editlock\":0,\"sys_language_uid\":0,\"l10n_parent\":0,\"l10n_source\":0,\"l10n_state\":null,\"t3_origuid\":0,\"l10n_diffsource\":\"\",\"t3ver_oid\":0,\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"perms_userid\":1,\"perms_groupid\":1,\"perms_user\":31,\"perms_group\":31,\"perms_everybody\":0,\"title\":\"Page with template\",\"slug\":\"\\/page-with-template\",\"doktype\":1,\"TSconfig\":null,\"is_siteroot\":0,\"php_tree_stop\":0,\"url\":\"\",\"shortcut\":0,\"shortcut_mode\":0,\"subtitle\":\"\",\"layout\":0,\"target\":\"\",\"media\":0,\"lastUpdated\":0,\"keywords\":null,\"cache_timeout\":0,\"cache_tags\":\"\",\"newUntil\":0,\"description\":null,\"no_search\":0,\"SYS_LASTCHANGED\":0,\"abstract\":null,\"module\":\"\",\"extendToSubpages\":0,\"author\":\"\",\"author_email\":\"\",\"nav_title\":\"\",\"nav_hide\":0,\"content_from_pid\":0,\"mount_pid\":0,\"mount_pid_ol\":0,\"l18n_cfg\":0,\"fe_login_mode\":0,\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"tsconfig_includes\":null,\"categories\":0,\"tx_impexp_origuid\":0,\"seo_title\":\"\",\"no_index\":0,\"no_follow\":0,\"og_title\":\"\",\"og_description\":null,\"og_image\":0,\"twitter_title\":\"\",\"twitter_description\":null,\"twitter_image\":0,\"twitter_card\":\"summary\",\"canonical_link\":\"\",\"sitemap_priority\":\"0.5\",\"sitemap_changefreq\":\"\",\"nav_icon_set\":\"\",\"nav_icon_identifier\":\"\",\"nav_icon\":0,\"thumbnail\":0,\"tx_pizpalue_background_image\":0}',0,'0400$c49d8cf8a220d8f7da204a512ea72af9:f11830df10b4b0bca2db34810c2241b3'),(11,1649338691,2,'BE',1,0,2,'pages','{\"oldRecord\":{\"hidden\":1,\"l10n_diffsource\":\"\"},\"newRecord\":{\"hidden\":\"0\",\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$87ab53547a0de6797e0a0b48068f24d9:f11830df10b4b0bca2db34810c2241b3'),(12,1649338706,1,'BE',1,0,3,'pages','{\"uid\":3,\"pid\":1,\"tstamp\":1649338706,\"crdate\":1649338706,\"cruser_id\":1,\"deleted\":0,\"hidden\":1,\"starttime\":0,\"endtime\":0,\"fe_group\":\"0\",\"sorting\":512,\"rowDescription\":null,\"editlock\":0,\"sys_language_uid\":0,\"l10n_parent\":0,\"l10n_source\":0,\"l10n_state\":null,\"t3_origuid\":0,\"l10n_diffsource\":\"\",\"t3ver_oid\":0,\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"perms_userid\":1,\"perms_groupid\":1,\"perms_user\":31,\"perms_group\":31,\"perms_everybody\":0,\"title\":\"Page without template\",\"slug\":\"\\/page-without-template\",\"doktype\":1,\"TSconfig\":null,\"is_siteroot\":0,\"php_tree_stop\":0,\"url\":\"\",\"shortcut\":0,\"shortcut_mode\":0,\"subtitle\":\"\",\"layout\":0,\"target\":\"\",\"media\":0,\"lastUpdated\":0,\"keywords\":null,\"cache_timeout\":0,\"cache_tags\":\"\",\"newUntil\":0,\"description\":null,\"no_search\":0,\"SYS_LASTCHANGED\":0,\"abstract\":null,\"module\":\"\",\"extendToSubpages\":0,\"author\":\"\",\"author_email\":\"\",\"nav_title\":\"\",\"nav_hide\":0,\"content_from_pid\":0,\"mount_pid\":0,\"mount_pid_ol\":0,\"l18n_cfg\":0,\"fe_login_mode\":0,\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"tsconfig_includes\":null,\"categories\":0,\"tx_impexp_origuid\":0,\"seo_title\":\"\",\"no_index\":0,\"no_follow\":0,\"og_title\":\"\",\"og_description\":null,\"og_image\":0,\"twitter_title\":\"\",\"twitter_description\":null,\"twitter_image\":0,\"twitter_card\":\"summary\",\"canonical_link\":\"\",\"sitemap_priority\":\"0.5\",\"sitemap_changefreq\":\"\",\"nav_icon_set\":\"\",\"nav_icon_identifier\":\"\",\"nav_icon\":0,\"thumbnail\":0,\"tx_pizpalue_background_image\":0}',0,'0400$cb7b676c892ad6473716e14702bb9c9f:fe15eeb7d49e64e2cea91ab53fcf0db1'),(13,1649338710,2,'BE',1,0,3,'pages','{\"oldRecord\":{\"hidden\":1,\"l10n_diffsource\":\"\"},\"newRecord\":{\"hidden\":\"0\",\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$eb3debcd010d3c87688a264d33384842:fe15eeb7d49e64e2cea91ab53fcf0db1'),(14,1649338776,1,'BE',1,0,2,'sys_template','{\"uid\":2,\"pid\":2,\"tstamp\":1649338776,\"crdate\":1649338776,\"cruser_id\":1,\"deleted\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"sorting\":256,\"description\":null,\"t3_origuid\":0,\"t3ver_oid\":0,\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"title\":\"+ext\",\"root\":0,\"clear\":0,\"include_static_file\":null,\"constants\":null,\"config\":null,\"basedOn\":\"\",\"includeStaticAfterBasedOn\":0,\"static_file_mode\":0,\"tx_impexp_origuid\":0}',0,'0400$2cff9e0ed7735dba722c3fdb2c97d6a6:092a6d165d49be6de27c1b2c5d7d6698'),(15,1649338787,4,'BE',1,0,2,'sys_template',NULL,0,'0400$181086a0318c6027620bf4853e41306f:092a6d165d49be6de27c1b2c5d7d6698'),(16,1649338793,1,'BE',1,0,3,'sys_template','{\"uid\":3,\"pid\":2,\"tstamp\":1649338793,\"crdate\":1649338793,\"cruser_id\":1,\"deleted\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"sorting\":256,\"description\":null,\"t3_origuid\":0,\"t3ver_oid\":0,\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"title\":\"+ext\",\"root\":0,\"clear\":0,\"include_static_file\":null,\"constants\":null,\"config\":null,\"basedOn\":\"\",\"includeStaticAfterBasedOn\":0,\"static_file_mode\":0,\"tx_impexp_origuid\":0}',0,'0400$b7cff12cc8f80701df4c08afbd5e5f99:b88ca63c030b2d23227de0950118f07a'),(17,1649340435,2,'BE',1,0,1,'sys_template','{\"oldRecord\":{\"constants\":\"\\r\\n\\r\\n# The following line has been added automatically by the extension easyconf\\r\\n@import \'fileadmin\\/tx_easyconf\\/Configuration\\/TypoScript\\/Constants1.typoscript\\/\'\\r\\n\"},\"newRecord\":{\"constants\":\"\\r\\n# The following line has been added automatically by the extension easyconf\\r\\n@import \'fileadmin\\/tx_easyconf\\/Configuration\\/TypoScript\\/Constants1.typoscript\\/\'\\r\\n\\r\\nmodule.tx_easyconf.constantsDirectory = EXT:easyconf\\/\"}}',0,'0400$b9a72acf1cda1b3249efa97518413752:35af6288617af54964e77af08c30949a'),(18,1649340697,2,'BE',1,0,1,'sys_template','{\"oldRecord\":{\"constants\":\"\\r\\n# The following line has been added automatically by the extension easyconf\\r\\n@import \'fileadmin\\/tx_easyconf\\/Configuration\\/TypoScript\\/Constants1.typoscript\\/\'\\r\\n\\r\\nmodule.tx_easyconf.constantsDirectory = EXT:easyconf\\/\"},\"newRecord\":{\"constants\":\"# The following line has been added automatically by the extension easyconf\\r\\n@import \'fileadmin\\/tx_easyconf\\/Configuration\\/TypoScript\\/Constants1.typoscript\\/\'\\r\\n\\r\\nmodule.tx_easyconf.constantsFileLocation = EXT:easyconf\\/\"}}',0,'0400$5600a8df06ee486230bd991fb1a62878:35af6288617af54964e77af08c30949a'),(19,1649340803,2,'BE',1,0,1,'sys_template','{\"oldRecord\":{\"constants\":\"# The following line has been added automatically by the extension easyconf\\r\\n@import \'fileadmin\\/tx_easyconf\\/Configuration\\/TypoScript\\/Constants1.typoscript\\/\'\\r\\n\\r\\nmodule.tx_easyconf.constantsFileLocation = EXT:easyconf\\/\"},\"newRecord\":{\"constants\":\"# The following line has been added automatically by the extension easyconf\\r\\n@import \'fileadmin\\/tx_easyconf\\/Configuration\\/TypoScript\\/Constants1.typoscript\\/\'\\r\\n\\r\\nmodule.tx_easyconf.constantsFileLocation = EXT:easyconf\"}}',0,'0400$e4cabbf14e21bce455a356a13f149750:35af6288617af54964e77af08c30949a'),(20,1649341627,2,'BE',1,0,1,'sys_template','{\"oldRecord\":{\"constants\":\"# The following line has been added automatically by the extension easyconf\\r\\n@import \'fileadmin\\/tx_easyconf\\/Configuration\\/TypoScript\\/Constants1.typoscript\\/\'\\r\\n\\r\\nmodule.tx_easyconf.constantsFileLocation = EXT:easyconf\"},\"newRecord\":{\"constants\":\"# The following line has been added automatically by the extension easyconf\\r\\n@import \'fileadmin\\/tx_easyconf\\/Configuration\\/TypoScript\\/Constants1.typoscript\\/\'\\r\\n\\r\\nmodule.tx_easyconf.constantsFileLocation = EXT:easyconf\\/\"}}',0,'0400$35c143343231eafb46198f34fa356b8d:35af6288617af54964e77af08c30949a'),(21,1649341682,2,'BE',1,0,1,'sys_template','{\"oldRecord\":{\"constants\":\"# The following line has been added automatically by the extension easyconf\\r\\n@import \'fileadmin\\/tx_easyconf\\/Configuration\\/TypoScript\\/Constants1.typoscript\\/\'\\r\\n\\r\\nmodule.tx_easyconf.constantsFileLocation = EXT:easyconf\\/\"},\"newRecord\":{\"constants\":\"# The following line has been added automatically by the extension easyconf\\r\\n@import \'fileadmin\\/tx_easyconf\\/Configuration\\/TypoScript\\/Constants1.typoscript\\/\'\\r\\n\\r\\nmodule.tx_easyconf.constantsFileLocation = fileadmin\\/testit\"}}',0,'0400$7786064b438d470f1159df84702c0aa7:35af6288617af54964e77af08c30949a'),(22,1649341714,2,'BE',1,0,1,'sys_template','{\"oldRecord\":{\"constants\":\"# The following line has been added automatically by the extension easyconf\\r\\n@import \'fileadmin\\/tx_easyconf\\/Configuration\\/TypoScript\\/Constants1.typoscript\\/\'\\r\\n\\r\\nmodule.tx_easyconf.constantsFileLocation = fileadmin\\/testit\"},\"newRecord\":{\"constants\":\"# The following line has been added automatically by the extension easyconf\\r\\n@import \'fileadmin\\/tx_easyconf\\/Configuration\\/TypoScript\\/Constants1.typoscript\\/\'\\r\\n\\r\\nmodule.tx_easyconf.constantsFileLocation = fileadmin\\/testit\\/\"}}',0,'0400$65799ffc0b380bb8bd6cd2fe92c35b36:35af6288617af54964e77af08c30949a'),(23,1649341829,2,'BE',1,0,1,'sys_template','{\"oldRecord\":{\"constants\":\"# The following line has been added automatically by the extension easyconf\\r\\n@import \'fileadmin\\/tx_easyconf\\/Configuration\\/TypoScript\\/Constants1.typoscript\\/\'\\r\\n\\r\\nmodule.tx_easyconf.constantsFileLocation = fileadmin\\/testit\\/\"},\"newRecord\":{\"constants\":\"# The following line has been added automatically by the extension easyconf\\r\\n@import \'fileadmin\\/tx_easyconf\\/Configuration\\/TypoScript\\/Constants1.typoscript\\/\'\\r\\n\\r\\nmodule.tx_easyconf.constantsFileLocation = \"}}',0,'0400$ccbe9375a8439832d394307ceb968c58:35af6288617af54964e77af08c30949a'),(24,1649341895,2,'BE',1,0,1,'sys_template','{\"oldRecord\":{\"constants\":\"# The following line has been added automatically by the extension easyconf\\r\\n@import \'fileadmin\\/tx_easyconf\\/Configuration\\/TypoScript\\/Constants1.typoscript\\/\'\\r\\n\\r\\nmodule.tx_easyconf.constantsFileLocation = \"},\"newRecord\":{\"constants\":\"# The following line has been added automatically by the extension easyconf\\r\\n@import \'fileadmin\\/tx_easyconf\\/Configuration\\/TypoScript\\/Constants1.typoscript\\/\'\\r\\n\\r\\nmodule.tx_easyconf.constantsFileLocation =      \"}}',0,'0400$2e07538144a995c99aa7042e68a8bb91:35af6288617af54964e77af08c30949a'),(25,1649342437,2,'BE',1,0,1,'sys_template','{\"oldRecord\":{\"constants\":\"# The following line has been added automatically by the extension easyconf\\r\\n@import \'fileadmin\\/tx_easyconf\\/Configuration\\/TypoScript\\/Constants1.typoscript\\/\'\\r\\n\\r\\nmodule.tx_easyconf.constantsFileLocation =      \"},\"newRecord\":{\"constants\":\"# The following line has been added automatically by the extension easyconf\\r\\n@import \'fileadmin\\/tx_easyconf\\/Configuration\\/TypoScript\\/Constants1.typoscript\\/\'\\r\\n\\r\\n# tx_easyconf; type=string; label=TypoScript file location:Folder where TypoScript constants are stored (e.g. fileadmin\\/ or EXT:my_ext\\/)\\r\\nmodule.tx_easyconf.typoScriptConstantMapper.fileLocation =   \"}}',0,'0400$20d2b5b7adec35c7bac68a2a914fa7f7:35af6288617af54964e77af08c30949a'),(26,1649342502,2,'BE',1,0,1,'sys_template','{\"oldRecord\":{\"constants\":\"# The following line has been added automatically by the extension easyconf\\r\\n@import \'fileadmin\\/tx_easyconf\\/Configuration\\/TypoScript\\/Constants1.typoscript\\/\'\\r\\n\\r\\n# tx_easyconf; type=string; label=TypoScript file location:Folder where TypoScript constants are stored (e.g. fileadmin\\/ or EXT:my_ext\\/)\\r\\nmodule.tx_easyconf.typoScriptConstantMapper.fileLocation =   \"},\"newRecord\":{\"constants\":\"# The following line has been added automatically by the extension easyconf\\r\\n@import \'fileadmin\\/tx_easyconf\\/Configuration\\/TypoScript\\/Constants1.typoscript\\/\'\\r\\n  \"}}',0,'0400$38d18dc0dbadbe3b4d3be7fe4b2c3a27:35af6288617af54964e77af08c30949a'),(27,1649343977,2,'BE',1,0,1,'sys_template','{\"oldRecord\":{\"constants\":\"# The following line has been added automatically by the extension easyconf\\r\\n@import \'fileadmin\\/tx_easyconf\\/Configuration\\/TypoScript\\/Constants1.typoscript\\/\'\\r\\n  \"},\"newRecord\":{\"constants\":\"# The following line has been added automatically by the extension easyconf\\r\\n@import \'fileadmin\\/tx_easyconf\\/Configuration\\/TypoScript\\/Constants1.typoscript\\/\'\\r\\n  \\nmodule.tx_easyconf.typoScriptConstantMapper.storage = fileadmin\\/test\"}}',0,'0400$a8afd028d73830bf9246970cfef9c71b:35af6288617af54964e77af08c30949a'),(28,1649344023,2,'BE',1,0,1,'sys_template','{\"oldRecord\":{\"constants\":\"# The following line has been added automatically by the extension easyconf\\r\\n@import \'fileadmin\\/tx_easyconf\\/Configuration\\/TypoScript\\/Constants1.typoscript\\/\'\\r\\n  \\nmodule.tx_easyconf.typoScriptConstantMapper.storage = fileadmin\\/test\"},\"newRecord\":{\"constants\":\"# The following line has been added automatically by the extension easyconf\\r\\n@import \'fileadmin\\/tx_easyconf\\/Configuration\\/TypoScript\\/Constants1.typoscript\\/\'\\r\\n  \\nmodule.tx_easyconf.typoScriptConstantMapper.storage = EXT:easyconf\"}}',0,'0400$8d07bcd64fef7046459de4f1353109bb:35af6288617af54964e77af08c30949a'),(29,1649344056,2,'BE',1,0,1,'sys_template','{\"oldRecord\":{\"constants\":\"# The following line has been added automatically by the extension easyconf\\r\\n@import \'fileadmin\\/tx_easyconf\\/Configuration\\/TypoScript\\/Constants1.typoscript\\/\'\\r\\n  \\nmodule.tx_easyconf.typoScriptConstantMapper.storage = EXT:easyconf\"},\"newRecord\":{\"constants\":\"# The following line has been added automatically by the extension easyconf\\r\\n@import \'fileadmin\\/tx_easyconf\\/Configuration\\/TypoScript\\/Constants1.typoscript\\/\'\\r\\n  \\nmodule.tx_easyconf.typoScriptConstantMapper.storage = \"}}',0,'0400$87fbb6f166ec201ffeaf9eea059a73ba:35af6288617af54964e77af08c30949a'),(30,1649391193,2,'BE',1,0,1,'sys_template','{\"oldRecord\":{\"constants\":\"module.tx_easyconf.typoScriptConstantMapper.storage =\\r\\n@import \'\\r\\n\'\\r\\n\\r\\n# The following line has been added automatically by the extension easyconf\\r\\n@import \'fileadmin\\/tx_easyconf\\/Configuration\\/TypoScript\\/Constants1.typoscript\\/\'\\r\\n\"},\"newRecord\":{\"constants\":\"module.tx_easyconf.typoScriptConstantMapper.storage =\\r\\n\\r\\n# The following line has been added automatically by the extension easyconf\\r\\n@import \'fileadmin\\/tx_easyconf\\/Configuration\\/TypoScript\\/Constants1.typoscript\\/\'\\r\\n\"}}',0,'0400$94ddc1755da4a880a544b888c67bb572:35af6288617af54964e77af08c30949a'),(31,1649391297,2,'BE',1,0,1,'sys_template','{\"oldRecord\":{\"constants\":\"module.tx_easyconf.typoScriptConstantMapper.storage =\\r\\n\\r\\n# The following line has been added automatically by the extension easyconf\\r\\n@import \'fileadmin\\/tx_easyconf\\/Configuration\\/TypoScript\\/Constants1.typoscript\\/\'\\r\\n\"},\"newRecord\":{\"constants\":\"\"}}',0,'0400$c457dc5b8c1ba28b62949c29f164f5ab:35af6288617af54964e77af08c30949a'),(32,1649391394,2,'BE',1,0,1,'sys_template','{\"oldRecord\":{\"constants\":\"\\r\\n\\r\\n# The following line has been added automatically by the extension easyconf\\r\\n@import \'fileadmin\\/tx_easyconf\\/Configuration\\/TypoScript\\/Constants1.typoscript\\/\'\\r\\n\"},\"newRecord\":{\"constants\":\"\\r\\n\\r\\nmodule.tx_easyconf.typoScriptConstantMapper.storage =\"}}',0,'0400$f27f868310c447ecfe7d79f729364234:35af6288617af54964e77af08c30949a'),(33,1649392379,2,'BE',1,0,1,'sys_template','{\"oldRecord\":{\"constants\":\"\\r\\n\\r\\nmodule.tx_easyconf.typoScriptConstantMapper.storage =\\r\\n\\r\\n# The following line has been added automatically by the extension easyconf\\r\\n@import \'fileadmin\\/tx_easyconf\\/Configuration\\/TypoScript\\/Constants1.typoscript\\/\'\\r\\n\"},\"newRecord\":{\"constants\":\"\\r\\nmodule.tx_easyconf.typoScriptConstantMapper.storage =\\r\\n\\r\\n# The following line has been added automatically by the extension easyconf\\r\\n@import \'fileadmin\\/tx_easyconf\\/Configuration\\/TypoScript\\/Constants1.typoscript\\/\'\\r\\n  \\r\\nmodule.tx_easyconf.typoScriptConstantMapper.storage =\\r\\n\"}}',0,'0400$1ace60832fe193ea20a9de293e0bcabb:35af6288617af54964e77af08c30949a'),(34,1649392417,2,'BE',1,0,1,'sys_template','{\"oldRecord\":{\"constants\":\"module.tx_easyconf.typoScriptConstantMapper.storage =\\r\\nmodule.tx_easyconf.typoScriptConstantMapper.storage =\\r\\n\\r\\n# The following line has been added automatically by the extension easyconf\\r\\n@import \'fileadmin\\/tx_easyconf\\/Configuration\\/TypoScript\\/Constants1.typoscript\\/\'\\r\\n\"},\"newRecord\":{\"constants\":\"module.tx_easyconf.typoScriptConstantMapper.storage =\\r\\n# The following line has been added automatically by the extension easyconf\\r\\n@import \'fileadmin\\/tx_easyconf\\/Configuration\\/TypoScript\\/Constants1.typoscript\\/\'\\r\\n\"}}',0,'0400$9b5b679bb78a38f9b59314c2bfb0bca9:35af6288617af54964e77af08c30949a'),(35,1649392887,2,'BE',1,0,1,'sys_template','{\"oldRecord\":{\"constants\":\"module.tx_easyconf.typoScriptConstantMapper.storage =\\r\\n\\r\\n# The following line has been added automatically by the extension easyconf\\r\\n@import \'fileadmin\\/tx_easyconf\\/Configuration\\/TypoScript\\/Constants1.typoscript\\/\'\\r\\n\"},\"newRecord\":{\"constants\":\"\"}}',0,'0400$7be10cffde1c49fa97bd73b02f965a16:35af6288617af54964e77af08c30949a'),(36,1649392918,2,'BE',1,0,1,'sys_template','{\"oldRecord\":{\"constants\":\"# The following line has been added automatically by the extension easyconf\\r\\n@import \'fileadmin\\/tx_easyconf\\/Configuration\\/TypoScript\\/Constants1.typoscript\\/\'\\r\\n\"},\"newRecord\":{\"constants\":\"module.tx_easyconf.typoScriptConstantMapper.storage =\"}}',0,'0400$c27ccfb797c1024a717284e8e2ba1301:35af6288617af54964e77af08c30949a'),(37,1649392943,2,'BE',1,0,1,'sys_template','{\"oldRecord\":{\"constants\":\"module.tx_easyconf.typoScriptConstantMapper.storage =# The following line has been added automatically by the extension easyconf\\r\\n@import \'fileadmin\\/tx_easyconf\\/Configuration\\/TypoScript\\/Constants1.typoscript\\/\'\\r\\n\"},\"newRecord\":{\"constants\":\"module.tx_easyconf.typoScriptConstantMapper.storage =\\r\\n\"}}',0,'0400$45a616868d53fb60462c9ca5490de7b5:35af6288617af54964e77af08c30949a'),(38,1649393002,2,'BE',1,0,1,'sys_template','{\"oldRecord\":{\"constants\":\"module.tx_easyconf.typoScriptConstantMapper.storage =\\r\\n\"},\"newRecord\":{\"constants\":\"module.tx_easyconf.typoScriptConstantMapper.storage =\"}}',0,'0400$2b6731ba862f636f660187e9f0eb2fbe:35af6288617af54964e77af08c30949a'),(39,1649393128,2,'BE',1,0,1,'sys_template','{\"oldRecord\":{\"constants\":\"module.tx_easyconf.typoScriptConstantMapper.storage =# The following line has been added automatically by the extension easyconf\\r\\n@import \'fileadmin\\/tx_easyconf\\/Configuration\\/TypoScript\\/Constants1.typoscript\\/\'\\r\\n\"},\"newRecord\":{\"constants\":\"module.tx_easyconf.typoScriptConstantMapper.storage =\"}}',0,'0400$d27e1bbed3877d45662033261cd82263:35af6288617af54964e77af08c30949a'),(40,1649393178,2,'BE',1,0,1,'sys_template','{\"oldRecord\":{\"constants\":\"module.tx_easyconf.typoScriptConstantMapper.storage =\\r\\n\\r\\n# The following line has been added automatically by the extension easyconf\\r\\n@import \'fileadmin\\/tx_easyconf\\/Configuration\\/TypoScript\\/Constants1.typoscript\\/\'\"},\"newRecord\":{\"constants\":\"# The following line has been added automatically by the extension easyconf\\r\\n@import \'fileadmin\\/tx_easyconf\\/Configuration\\/TypoScript\\/Constants1.typoscript\\/\'\\r\\n  \\r\\nmodule.tx_easyconf.typoScriptConstantMapper.storage =\"}}',0,'0400$c80d9030283f2e903b057bb26ea90fdf:35af6288617af54964e77af08c30949a'),(41,1649393230,2,'BE',1,0,1,'sys_template','{\"oldRecord\":{\"constants\":\"module.tx_easyconf.typoScriptConstantMapper.storage =\\r\\n\\r\\n# The following line has been added automatically by the extension easyconf\\r\\n@import \'fileadmin\\/tx_easyconf\\/Configuration\\/TypoScript\\/Constants1.typoscript\\/\'\"},\"newRecord\":{\"constants\":\"module.tx_easyconf.typoScriptConstantMapper.storage =\\r\\n\\r\\n# The following line has been added automatically by the extension easyconf\\r\\n@import \'fileadmin\\/tx_easyconf\\/Configuration\\/TypoScript\\/Constants1.typoscript\\/\'\\r\\n\\r\\nmodule.tx_easyconf.typoScriptConstantMapper.storage =\"}}',0,'0400$855d20dca07bc42b2ee3f63fa9c1bde2:35af6288617af54964e77af08c30949a'),(42,1649393290,2,'BE',1,0,1,'sys_template','{\"oldRecord\":{\"constants\":\"module.tx_easyconf.typoScriptConstantMapper.storage =\\r\\nmodule.tx_easyconf.typoScriptConstantMapper.storage =\\r\\n\\r\\n# The following line has been added automatically by the extension easyconf\\r\\n@import \'fileadmin\\/tx_easyconf\\/Configuration\\/TypoScript\\/Constants1.typoscript\\/\'\"},\"newRecord\":{\"constants\":\"module.tx_easyconf.typoScriptConstantMapper.storage =\\r\\n\\r\\n# The following line has been added automatically by the extension easyconf\\r\\n@import \'fileadmin\\/tx_easyconf\\/Configuration\\/TypoScript\\/Constants1.typoscript\\/\'\"}}',0,'0400$18c4e9c960618eb3af8602c504476b57:35af6288617af54964e77af08c30949a'),(43,1649395545,2,'BE',1,0,1,'sys_template','{\"oldRecord\":{\"constants\":\"module.tx_easyconf.typoScriptConstantMapper.storage =\\r\\n\\r\\n# The following line has been added automatically by the extension easyconf\\r\\n@import \'fileadmin\\/tx_easyconf\\/Configuration\\/TypoScript\\/Constants1.typoscript\\/\'\"},\"newRecord\":{\"constants\":\"# The following line has been added automatically by the extension easyconf\\r\\n@import \'fileadmin\\/tx_easyconf\\/Configuration\\/TypoScript\\/Constants1.typoscript\\/\'\"}}',0,'0400$afc9bd045bcffdde45756c69865f19c8:35af6288617af54964e77af08c30949a'),(44,1649395569,2,'BE',1,0,1,'sys_template','{\"oldRecord\":{\"constants\":\"\\r\\n\\r\\n# The following line has been added automatically by the extension easyconf\\r\\n@import \'fileadmin\\/tx_easyconf\\/Configuration\\/TypoScript\\/Constants1.typoscript\\/\'\"},\"newRecord\":{\"constants\":\"module.tx_easyconf.typoScriptConstantMapper.storage =\\r\\n\\r\\n# The following line has been added automatically by the extension easyconf\\r\\n@import \'fileadmin\\/tx_easyconf\\/Configuration\\/TypoScript\\/Constants1.typoscript\\/\'\"}}',0,'0400$2c3cfb9675e84823914bcfca5e17456a:35af6288617af54964e77af08c30949a'),(45,1649395596,2,'BE',1,0,1,'sys_template','{\"oldRecord\":{\"constants\":\"module.tx_easyconf.typoScriptConstantMapper.storage =\\r\\n\\r\\n# The following line has been added automatically by the extension easyconf\\r\\n@import \'fileadmin\\/tx_easyconf\\/Configuration\\/TypoScript\\/Constants1.typoscript\\/\'\"},\"newRecord\":{\"constants\":\"module.tx_easyconf.typoScriptConstantMapper.storage =\\r\\n\\r\\n# The following line has been added automatically by the extension easyconf\\r\\n@import \'fileadmin\\/tx_easyconf\\/Configuration\\/TypoScript\\/Constants1.typoscript\\/\'\\r\\n  \\r\\nmodule.tx_easyconf.typoScriptConstantMapper.storage =\"}}',0,'0400$928ec191fd6bf5fbc052f20d4cce8c74:35af6288617af54964e77af08c30949a'),(46,1649395622,2,'BE',1,0,1,'sys_template','{\"oldRecord\":{\"constants\":\"module.tx_easyconf.typoScriptConstantMapper.storage =\\r\\nmodule.tx_easyconf.typoScriptConstantMapper.storage =\\r\\n\\r\\n# The following line has been added automatically by the extension easyconf\\r\\n@import \'fileadmin\\/tx_easyconf\\/Configuration\\/TypoScript\\/Constants1.typoscript\\/\'\"},\"newRecord\":{\"constants\":\"module.tx_easyconf.typoScriptConstantMapper.storage =\\r\\nmodule.tx_easyconf.typoScriptConstantMapper.storage =\\r\\n\\r\\n# The following line has been added automatically by the extension easyconf\\r\\n@import \'fileadmin\\/tx_easyconf\\/Configuration\\/TypoScript\\/Constants1.typoscript\\/\'\\nmodule.tx_easyconf.typoScriptConstantMapper.importStatementHandling = addOnce\"}}',0,'0400$3c7753ce000b00ed0f1c863cd436aeb9:35af6288617af54964e77af08c30949a'),(47,1649395706,2,'BE',1,0,1,'sys_template','{\"oldRecord\":{\"constants\":\"module.tx_easyconf.typoScriptConstantMapper.storage =\\r\\nmodule.tx_easyconf.typoScriptConstantMapper.storage =\\r\\nmodule.tx_easyconf.typoScriptConstantMapper.importStatementHandling = addOnce\\r\\n\\r\\n# The following line has been added automatically by the extension easyconf\\r\\n@import \'fileadmin\\/tx_easyconf\\/Configuration\\/TypoScript\\/Constants1.typoscript\\/\'\"},\"newRecord\":{\"constants\":\"module.tx_easyconf.typoScriptConstantMapper.storage =\\r\\nmodule.tx_easyconf.typoScriptConstantMapper.storage =\\r\\n\\r\\n# The following line has been added automatically by the extension easyconf\\r\\n@import \'fileadmin\\/tx_easyconf\\/Configuration\\/TypoScript\\/Constants1.typoscript\\/\'\\r\\n  \\r\\nmodule.tx_easyconf.typoScriptConstantMapper.importStatementHandling = addOnce\"}}',0,'0400$09d66822fc26b4b0ca6cc6c5c5501678:35af6288617af54964e77af08c30949a'),(48,1649395737,2,'BE',1,0,1,'sys_template','{\"oldRecord\":{\"constants\":\"module.tx_easyconf.typoScriptConstantMapper.storage =\\r\\nmodule.tx_easyconf.typoScriptConstantMapper.storage =\\r\\nmodule.tx_easyconf.typoScriptConstantMapper.importStatementHandling = addOnce\\r\\n\\r\\n# The following line has been added automatically by the extension easyconf\\r\\n@import \'fileadmin\\/tx_easyconf\\/Configuration\\/TypoScript\\/Constants1.typoscript\\/\'\"},\"newRecord\":{\"constants\":\"module.tx_easyconf.typoScriptConstantMapper.storage =\\r\\nmodule.tx_easyconf.typoScriptConstantMapper.storage =\\r\\n\\r\\n# The following line has been added automatically by the extension easyconf\\r\\n@import \'fileadmin\\/tx_easyconf\\/Configuration\\/TypoScript\\/Constants1.typoscript\\/\'\\r\\n  \\r\\nmodule.tx_easyconf.typoScriptConstantMapper.importStatementHandling = addOnce\"}}',0,'0400$fbd009f2e2ee59bf8c349a2e6d843602:35af6288617af54964e77af08c30949a'),(49,1649395868,2,'BE',1,0,1,'sys_template','{\"oldRecord\":{\"constants\":\"module.tx_easyconf.typoScriptConstantMapper.storage =\\r\\nmodule.tx_easyconf.typoScriptConstantMapper.storage =\\r\\nmodule.tx_easyconf.typoScriptConstantMapper.importStatementHandling = addOnce\\r\\n\\r\\n# The following line has been added automatically by the extension easyconf\\r\\n@import \'fileadmin\\/tx_easyconf\\/Configuration\\/TypoScript\\/Constants1.typoscript\\/\'\"},\"newRecord\":{\"constants\":\"module.tx_easyconf.typoScriptConstantMapper.storage =\\r\\nmodule.tx_easyconf.typoScriptConstantMapper.storage =\\r\\n\\r\\n# The following line has been added automatically by the extension easyconf\\r\\n@import \'fileadmin\\/tx_easyconf\\/Configuration\\/TypoScript\\/Constants1.typoscript\\/\'\\r\\n  \\r\\nmodule.tx_easyconf.typoScriptConstantMapper.importStatementHandling = addOnce\"}}',0,'0400$8b60605f2bcc23202a891a683c1c822b:35af6288617af54964e77af08c30949a'),(50,1649395899,2,'BE',1,0,1,'sys_template','{\"oldRecord\":{\"constants\":\"module.tx_easyconf.typoScriptConstantMapper.storage =\\r\\nmodule.tx_easyconf.typoScriptConstantMapper.storage =\\r\\n\\r\\n# The following line has been added automatically by the extension easyconf\\r\\n@import \'fileadmin\\/tx_easyconf\\/Configuration\\/TypoScript\\/Constants1.typoscript\\/\'\\r\\n  \\r\\nmodule.tx_easyconf.typoScriptConstantMapper.importStatementHandling = addOnce\"},\"newRecord\":{\"constants\":\"module.tx_easyconf.typoScriptConstantMapper.storage =\\r\\nmodule.tx_easyconf.typoScriptConstantMapper.storage =\\r\\n\\r\\n# The following line has been added automatically by the extension easyconf\\r\\n@import \'fileadmin\\/tx_easyconf\\/Configuration\\/TypoScript\\/Constants1.typoscript\\/\'\\r\\n  \\r\\nmodule.tx_easyconf.typoScriptConstantMapper.importStatementHandling = \"}}',0,'0400$42d93a8c81b9cdd3e0c3a5abaaef6809:35af6288617af54964e77af08c30949a'),(51,1649395925,2,'BE',1,0,1,'sys_template','{\"oldRecord\":{\"constants\":\"module.tx_easyconf.typoScriptConstantMapper.storage =\\r\\nmodule.tx_easyconf.typoScriptConstantMapper.storage =\\r\\nmodule.tx_easyconf.typoScriptConstantMapper.importStatementHandling =\\r\\n\\r\\n# The following line has been added automatically by the extension easyconf\\r\\n@import \'fileadmin\\/tx_easyconf\\/Configuration\\/TypoScript\\/Constants1.typoscript\\/\'\"},\"newRecord\":{\"constants\":\"module.tx_easyconf.typoScriptConstantMapper.storage =\\r\\nmodule.tx_easyconf.typoScriptConstantMapper.importStatementHandling =\\r\\n\\r\\n# The following line has been added automatically by the extension easyconf\\r\\n@import \'fileadmin\\/tx_easyconf\\/Configuration\\/TypoScript\\/Constants1.typoscript\\/\'\"}}',0,'0400$2d87e544cf3bf6d0ca103a5bbdea7111:35af6288617af54964e77af08c30949a'),(52,1649667637,4,'BE',1,0,4,'tx_easyconf_configuration',NULL,0,'0400$2e1c0ceebfb51b18a1582f3fe8e22a18:2cf9633e8cfb33b8ebe77978d9527539'),(53,1649668046,4,'BE',1,0,6,'tx_easyconf_configuration',NULL,0,'0400$275c64663ea7851457a166261d8a5edd:cd1ee45106eaaff671533eff3e61c35c'),(54,1649668108,4,'BE',1,0,7,'tx_easyconf_configuration',NULL,0,'0400$3646c07c503311af4b79b588b2720679:295f233fc60681315f14fed0e4404fe2'),(55,1649668202,4,'BE',1,0,8,'tx_easyconf_configuration',NULL,0,'0400$ec5db48f1a3b2efa4aa9cb424c896db2:a7b3ca86dc511ab5c2d50ef96e2537ae'),(56,1649910247,2,'BE',1,0,3,'sys_template','{\"oldRecord\":{\"constants\":\"\\r\\n\\r\\n# The following line has been added automatically by the extension easyconf\\r\\n@import \'fileadmin\\/tx_easyconf\\/Configuration\\/TypoScript\\/Constants3.typoscript\\/\'\"},\"newRecord\":{\"constants\":\"\\r\\n# The following line has been added automatically by the extension easyconf\\r\\n@import \'fileadmin\\/easyconf\\/Configuration\\/TypoScript\\/Constants3.typoscript\\/\'\"}}',0,'0400$a40af951d22b1b3dfc486b2fb0d56f8f:b88ca63c030b2d23227de0950118f07a'),(57,1649919221,1,'BE',1,0,4,'pages','{\"uid\":4,\"pid\":2,\"tstamp\":1649919221,\"crdate\":1649919221,\"cruser_id\":1,\"deleted\":0,\"hidden\":1,\"starttime\":0,\"endtime\":0,\"fe_group\":\"0\",\"sorting\":256,\"rowDescription\":null,\"editlock\":0,\"sys_language_uid\":0,\"l10n_parent\":0,\"l10n_source\":0,\"l10n_state\":null,\"t3_origuid\":0,\"l10n_diffsource\":\"\",\"t3ver_oid\":0,\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"perms_userid\":1,\"perms_groupid\":1,\"perms_user\":31,\"perms_group\":31,\"perms_everybody\":0,\"title\":\"Subpage with template\",\"slug\":\"\\/page-with-template\\/subpage-with-template\",\"doktype\":1,\"TSconfig\":null,\"is_siteroot\":0,\"php_tree_stop\":0,\"url\":\"\",\"shortcut\":0,\"shortcut_mode\":0,\"subtitle\":\"\",\"layout\":0,\"target\":\"\",\"media\":0,\"lastUpdated\":0,\"keywords\":null,\"cache_timeout\":0,\"cache_tags\":\"\",\"newUntil\":0,\"description\":null,\"no_search\":0,\"SYS_LASTCHANGED\":0,\"abstract\":null,\"module\":\"\",\"extendToSubpages\":0,\"author\":\"\",\"author_email\":\"\",\"nav_title\":\"\",\"nav_hide\":0,\"content_from_pid\":0,\"mount_pid\":0,\"mount_pid_ol\":0,\"l18n_cfg\":0,\"fe_login_mode\":0,\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"tsconfig_includes\":null,\"categories\":0,\"tx_impexp_origuid\":0,\"seo_title\":\"\",\"no_index\":0,\"no_follow\":0,\"og_title\":\"\",\"og_description\":null,\"og_image\":0,\"twitter_title\":\"\",\"twitter_description\":null,\"twitter_image\":0,\"twitter_card\":\"summary\",\"canonical_link\":\"\",\"sitemap_priority\":\"0.5\",\"sitemap_changefreq\":\"\",\"nav_icon_set\":\"\",\"nav_icon_identifier\":\"\",\"nav_icon\":0,\"thumbnail\":0,\"tx_pizpalue_background_image\":0}',0,'0400$3598c447b231820e404c37d7ccfb8083:412add0b3eb6ec8f1cb6710aea92e21e'),(58,1649919224,2,'BE',1,0,4,'pages','{\"oldRecord\":{\"hidden\":1,\"l10n_diffsource\":\"\"},\"newRecord\":{\"hidden\":\"0\",\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$c9958cf399899733fa545047c2ae3055:412add0b3eb6ec8f1cb6710aea92e21e'),(59,1649919244,1,'BE',1,0,4,'sys_template','{\"uid\":4,\"pid\":4,\"tstamp\":1649919244,\"crdate\":1649919244,\"cruser_id\":1,\"deleted\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"sorting\":256,\"description\":null,\"t3_origuid\":0,\"t3ver_oid\":0,\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"title\":\"+ext\",\"root\":0,\"clear\":0,\"include_static_file\":null,\"constants\":null,\"config\":null,\"basedOn\":\"\",\"includeStaticAfterBasedOn\":0,\"static_file_mode\":0,\"tx_impexp_origuid\":0}',0,'0400$f2e1422812f9844d29237a9679c43caf:dd5a25a295f53aea07abb5b4e121100d'),(60,1649919326,1,'BE',1,0,5,'pages','{\"uid\":5,\"pid\":3,\"tstamp\":1649919326,\"crdate\":1649919326,\"cruser_id\":1,\"deleted\":0,\"hidden\":1,\"starttime\":0,\"endtime\":0,\"fe_group\":\"0\",\"sorting\":256,\"rowDescription\":null,\"editlock\":0,\"sys_language_uid\":0,\"l10n_parent\":0,\"l10n_source\":0,\"l10n_state\":null,\"t3_origuid\":0,\"l10n_diffsource\":\"\",\"t3ver_oid\":0,\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"perms_userid\":1,\"perms_groupid\":1,\"perms_user\":31,\"perms_group\":31,\"perms_everybody\":0,\"title\":\"Subpage with template\",\"slug\":\"\\/page-without-template\\/subpage-with-template\",\"doktype\":1,\"TSconfig\":null,\"is_siteroot\":0,\"php_tree_stop\":0,\"url\":\"\",\"shortcut\":0,\"shortcut_mode\":0,\"subtitle\":\"\",\"layout\":0,\"target\":\"\",\"media\":0,\"lastUpdated\":0,\"keywords\":null,\"cache_timeout\":0,\"cache_tags\":\"\",\"newUntil\":0,\"description\":null,\"no_search\":0,\"SYS_LASTCHANGED\":0,\"abstract\":null,\"module\":\"\",\"extendToSubpages\":0,\"author\":\"\",\"author_email\":\"\",\"nav_title\":\"\",\"nav_hide\":0,\"content_from_pid\":0,\"mount_pid\":0,\"mount_pid_ol\":0,\"l18n_cfg\":0,\"fe_login_mode\":0,\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"tsconfig_includes\":null,\"categories\":0,\"tx_impexp_origuid\":0,\"seo_title\":\"\",\"no_index\":0,\"no_follow\":0,\"og_title\":\"\",\"og_description\":null,\"og_image\":0,\"twitter_title\":\"\",\"twitter_description\":null,\"twitter_image\":0,\"twitter_card\":\"summary\",\"canonical_link\":\"\",\"sitemap_priority\":\"0.5\",\"sitemap_changefreq\":\"\",\"nav_icon_set\":\"\",\"nav_icon_identifier\":\"\",\"nav_icon\":0,\"thumbnail\":0,\"tx_pizpalue_background_image\":0}',0,'0400$57c93459cd3518c47964681d0f512e28:7ef5a4e3e11db8ac3fea4d7a75468161'),(61,1649919330,2,'BE',1,0,5,'pages','{\"oldRecord\":{\"hidden\":1,\"l10n_diffsource\":\"\"},\"newRecord\":{\"hidden\":\"0\",\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$d85d41a040ee636a18f445cf49acbb35:7ef5a4e3e11db8ac3fea4d7a75468161'),(62,1649919348,1,'BE',1,0,5,'sys_template','{\"uid\":5,\"pid\":5,\"tstamp\":1649919348,\"crdate\":1649919348,\"cruser_id\":1,\"deleted\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"sorting\":256,\"description\":null,\"t3_origuid\":0,\"t3ver_oid\":0,\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"title\":\"+ext\",\"root\":0,\"clear\":0,\"include_static_file\":null,\"constants\":null,\"config\":null,\"basedOn\":\"\",\"includeStaticAfterBasedOn\":0,\"static_file_mode\":0,\"tx_impexp_origuid\":0}',0,'0400$a98707037351be5e56e14e842be6d7d8:83b804a2d5e2d9e1e8b44f029dadef71'),(63,1649919551,2,'BE',1,0,1,'sys_template','{\"oldRecord\":{\"constants\":\"module.tx_easyconf.typoScriptConstantMapper.storage =\\r\\nmodule.tx_easyconf.typoScriptConstantMapper.importStatementHandling =\\r\\n\\r\\n# The following line has been added automatically by the extension easyconf\\r\\n@import \'fileadmin\\/tx_easyconf\\/Configuration\\/TypoScript\\/Constants1.typoscript\\/\'\\r\\n\\r\\n# The following line has been added automatically by the extension easyconf\\r\\n@import \'fileadmin\\/easyconf\\/Configuration\\/TypoScript\\/Constants1.typoscript\\/\'\"},\"newRecord\":{\"constants\":\"module.tx_easyconf.typoScriptConstantMapper.storage =\\r\\nmodule.tx_easyconf.typoScriptConstantMapper.importStatementHandling =\\r\\n\\r\\n# The following line has been added automatically by the extension easyconf\\r\\n@import \'fileadmin\\/easyconf\\/Configuration\\/TypoScript\\/Constants1.typoscript\\/\'\"}}',0,'0400$ce08221f5c04e165948d0b98cd23fe82:35af6288617af54964e77af08c30949a'),(64,1650612894,2,'BE',1,0,1,'sys_template','{\"oldRecord\":{\"constants\":\"module.tx_easyconf.typoScriptConstantMapper.storage =\\r\\nmodule.tx_easyconf.typoScriptConstantMapper.importStatementHandling =\\r\\n\\r\\n# The following line has been added automatically by the extension easyconf\\r\\n@import \'fileadmin\\/easyconf\\/Configuration\\/TypoScript\\/Constants1.typoscript\\/\'\\r\\n\\r\\n# The following line has been added automatically by the extension easyconf\\r\\n@import \'fileadmin\\/easyconf\\/Configuration\\/TypoScript\\/EasyconfConstantsP1T1.typoscript\\/\'\"},\"newRecord\":{\"constants\":\"module.tx_easyconf.typoScriptConstantMapper.storage =\\r\\nmodule.tx_easyconf.typoScriptConstantMapper.importStatementHandling =\\r\\n\\r\\n# The following line has been added automatically by the extension easyconf\\r\\n@import \'fileadmin\\/easyconf\\/Configuration\\/TypoScript\\/EasyconfConstantsP1T1.typoscript\\/\'\"}}',0,'0400$f630ef50e8c17b54f89202170b19c885:35af6288617af54964e77af08c30949a'),(65,1650612910,2,'BE',1,0,3,'sys_template','{\"oldRecord\":{\"constants\":\"# The following line has been added automatically by the extension easyconf\\r\\n@import \'fileadmin\\/easyconf\\/Configuration\\/TypoScript\\/Constants3.typoscript\\/\'\\r\\n\\r\\n# The following line has been added automatically by the extension easyconf\\r\\n@import \'fileadmin\\/easyconf\\/Configuration\\/TypoScript\\/EasyconfConstantsP2T3.typoscript\\/\'\"},\"newRecord\":{\"constants\":\"# The following line has been added automatically by the extension easyconf\\r\\n@import \'fileadmin\\/easyconf\\/Configuration\\/TypoScript\\/EasyconfConstantsP2T3.typoscript\\/\'\"}}',0,'0400$c6c4cc3e5834d8f0dda95d54b8b3d6f7:b88ca63c030b2d23227de0950118f07a'),(66,1650612924,2,'BE',1,0,4,'sys_template','{\"oldRecord\":{\"constants\":\"\\r\\n\\r\\n# The following line has been added automatically by the extension easyconf\\r\\n@import \'fileadmin\\/easyconf\\/Configuration\\/TypoScript\\/Constants4.typoscript\\/\'\"},\"newRecord\":{\"constants\":\"\"}}',0,'0400$ce48b34056045385a8f234f02fd313f0:dd5a25a295f53aea07abb5b4e121100d'),(67,1650612932,2,'BE',1,0,5,'sys_template','{\"oldRecord\":{\"constants\":\"\\r\\n\\r\\n# The following line has been added automatically by the extension easyconf\\r\\n@import \'fileadmin\\/easyconf\\/Configuration\\/TypoScript\\/Constants5.typoscript\\/\'\"},\"newRecord\":{\"constants\":\"\"}}',0,'0400$6350c3454252b7cbc471e176afb79067:83b804a2d5e2d9e1e8b44f029dadef71'),(68,1652722501,2,'BE',1,0,1,'sys_template','{\"oldRecord\":{\"constants\":\"module.tx_easyconf.typoScriptConstantMapper.storage =\\r\\nmodule.tx_easyconf.typoScriptConstantMapper.importStatementHandling =\\r\\n# The following line has been added automatically by the extension easyconf\\r\\n@import \'fileadmin\\/easyconf\\/Configuration\\/TypoScript\\/\\/EasyconfConstantsP1T1.typoscript\'\\r\\n\\r\\n# The following line has been added automatically by the extension easyconf\\r\\n@import \'fileadmin\\/easyconf\\/Configuration\\/TypoScript\\/EasyconfConstantsP1T1.typoscript\\/\'\\r\\n\\r\\n# The following line has been added automatically by the extension easyconf\\r\\n@import \'fileadmin\\/easyconf\\/Configuration\\/TypoScript\\/EasyconfConstantsP1T1.typoscript\'\"},\"newRecord\":{\"constants\":\"module.tx_easyconf.typoScriptConstantMapper.storage =\\r\\nmodule.tx_easyconf.typoScriptConstantMapper.importStatementHandling =\\r\\n\\r\\n# The following line has been added automatically by the extension easyconf\\r\\n@import \'fileadmin\\/easyconf\\/Configuration\\/TypoScript\\/EasyconfConstantsP1T1.typoscript\'\"}}',0,'0400$9f9a0c99745087b40471aa9ef0063e27:35af6288617af54964e77af08c30949a'),(69,1666243783,2,'BE',1,0,1,'sys_template','{\"oldRecord\":{\"constants\":\"module.tx_easyconf.typoScriptConstantMapper.storage =\\r\\nmodule.tx_easyconf.typoScriptConstantMapper.importStatementHandling =\\r\\n\\r\\n# The following line has been added automatically by the extension easyconf\\r\\n@import \'fileadmin\\/easyconf\\/Configuration\\/TypoScript\\/EasyconfConstantsP1T1.typoscript\'\"},\"newRecord\":{\"constants\":\"module.tx_easyconf.typoScriptConstantMapper.storage =\\r\\nmodule.tx_easyconf.typoScriptConstantMapper.importStatementHandling =\\r\\n\\r\\n# The following line has been added automatically by the extension easyconf\\r\\n@import \'fileadmin\\/easyconf\\/Configuration\\/TypoScript\\/EasyconfConstantsP1T10.typoscript\'\\r\\n\\r\\n# The following line has been added automatically by the extension easyconf\\r\\n@import \'fileadmin\\/easyconf\\/Configuration\\/TypoScript\\/EasyconfConstantsP1T1.typoscript\'\"}}',0,'0400$1f230c9f0dcccf7e10262656f4d90737:35af6288617af54964e77af08c30949a'),(70,1666243805,2,'BE',1,0,1,'sys_template','{\"oldRecord\":{\"constants\":\"module.tx_easyconf.typoScriptConstantMapper.storage =\\r\\nmodule.tx_easyconf.typoScriptConstantMapper.importStatementHandling =\\r\\n\\r\\n# The following line has been added automatically by the extension easyconf\\r\\n@import \'fileadmin\\/easyconf\\/Configuration\\/TypoScript\\/EasyconfConstantsP1T10.typoscript\'\\r\\n\\r\\n# The following line has been added automatically by the extension easyconf\\r\\n@import \'fileadmin\\/easyconf\\/Configuration\\/TypoScript\\/EasyconfConstantsP1T1.typoscript\'\"},\"newRecord\":{\"constants\":\"module.tx_easyconf.typoScriptConstantMapper.storage =\\r\\nmodule.tx_easyconf.typoScriptConstantMapper.importStatementHandling =\\r\\n\\r\\n# The following line has been added automatically by the extension easyconf\\r\\n@import \'fileadmin\\/easyconf\\/Configuration\\/TypoScript\\/EasyconfConstantsP1T10.typoscript\'\\r\\n\\r\\n# The following line has been added automatically by the extension easyconf\\r\\n@import \'fileadmin\\/easyconf\\/Configuration\\/TypoScript\\/EasyconfConstantsP10T1.typoscript\'\\r\\n\\r\\n# The following line has been added automatically by the extension easyconf\\r\\n@import \'fileadmin\\/easyconf\\/Configuration\\/TypoScript\\/EasyconfConstantsP10T10.typoscript\'\\r\\n\\r\\n# The following line has been added automatically by the extension easyconf\\r\\n@import \'fileadmin\\/easyconf\\/Configuration\\/TypoScript\\/EasyconfConstantsP1T1.typoscript\'\"}}',0,'0400$c5a669c686933b49c0dd7357daa84043:35af6288617af54964e77af08c30949a'),(71,1666245642,2,'BE',1,0,1,'sys_template','{\"oldRecord\":{\"constants\":\"module.tx_easyconf.typoScriptConstantMapper.storage =\\r\\nmodule.tx_easyconf.typoScriptConstantMapper.importStatementHandling =\\r\\n\\r\\n# The following line has been added automatically by the extension easyconf\\r\\n@import \'fileadmin\\/easyconf\\/Configuration\\/TypoScript\\/EasyconfConstantsP1T10.typoscript\'\\r\\n\\r\\n# The following line has been added automatically by the extension easyconf\\r\\n@import \'fileadmin\\/easyconf\\/Configuration\\/TypoScript\\/EasyconfConstantsP10T1.typoscript\'\\r\\n\\r\\n# The following line has been added automatically by the extension easyconf\\r\\n@import \'fileadmin\\/easyconf\\/Configuration\\/TypoScript\\/EasyconfConstantsP10T10.typoscript\'\\r\\n\\r\\n# The following line has been added automatically by the extension easyconf\\r\\n@import \'fileadmin\\/easyconf\\/Configuration\\/TypoScript\\/EasyconfConstantsP1T1.typoscript\'\"},\"newRecord\":{\"constants\":\"module.tx_easyconf.typoScriptConstantMapper.storage =\\r\\nmodule.tx_easyconf.typoScriptConstantMapper.importStatementHandling =\\r\\n\\r\\n# The following line has been added automatically by the extension easyconf\\r\\n@import \'fileadmin\\/easyconf\\/Configuration\\/TypoScript\\/EasyconfConstantsP1T10.typoscript\'\\r\\n\\r\\n# The following line has been added automatically by the extension easyconf\\r\\n@import \'fileadmin\\/easyconf\\/Configuration\\/TypoScript\\/EasyconfConstantsP10T1.typoscript\'\\r\\n\\r\\n# The following line has been added automatically by the extension easyconf\\r\\n@import \'fileadmin\\/easyconf\\/Configuration\\/TypoScript\\/EasyconfConstantsP10T10.typoscript\'\\r\\n\\r\\n# The following line has been added automatically by the extension easyconf\\r\\n@import \'fileadmin\\/easyconf\\/Configuration\\/TypoScript\\/EasyconfConstantsP1T1.typoscript\'\\r\\n\\r\\nfoo=1\"}}',0,'0400$ba47f65b8d73a1ea60bf6e6eaf9154b5:35af6288617af54964e77af08c30949a'),(72,1666245726,2,'BE',1,0,1,'sys_template','{\"oldRecord\":{\"constants\":\"module.tx_easyconf.typoScriptConstantMapper.storage =\\r\\nmodule.tx_easyconf.typoScriptConstantMapper.importStatementHandling =\\r\\nfoo=1\\r\\n\\r\\n# The following line has been added automatically by the extension easyconf\\r\\n@import \'fileadmin\\/easyconf\\/Configuration\\/TypoScript\\/EasyconfConstantsP1T1.typoscript\'\"},\"newRecord\":{\"constants\":\"module.tx_easyconf.typoScriptConstantMapper.storage =\\r\\nmodule.tx_easyconf.typoScriptConstantMapper.importStatementHandling =\\r\\n\\r\\n# The following line has been added automatically by the extension easyconf\\r\\n@import \'fileadmin\\/easyconf\\/Configuration\\/TypoScript\\/EasyconfConstantsP1T10.typoscript\'\\r\\n\\r\\n# The following line has been added automatically by the extension easyconf\\r\\n@import \'fileadmin\\/easyconf\\/Configuration\\/TypoScript\\/EasyconfConstantsP10T1.typoscript\'\\r\\n\\r\\n# The following line has been added automatically by the extension easyconf\\r\\n@import \'fileadmin\\/easyconf\\/Configuration\\/TypoScript\\/EasyconfConstantsP10T10.typoscript\'\\r\\n\\r\\n# The following line has been added automatically by the extension easyconf\\r\\n@import \'fileadmin\\/easyconf\\/Configuration\\/TypoScript\\/EasyconfConstantsP1T1.typoscript\'\"}}',0,'0400$772402ab696e7ce382c549865440779e:35af6288617af54964e77af08c30949a'),(73,1670918288,2,'BE',1,0,1,'sys_template','{\"oldRecord\":{\"config\":\"\"},\"newRecord\":{\"config\":\"\\nmodule.tx_easyconf.settings.support.phone = 111\"}}',0,'0400$022aa972d351362170422a610e8c4824:35af6288617af54964e77af08c30949a'),(74,1670918408,2,'BE',1,0,1,'sys_template','{\"oldRecord\":{\"config\":\"\\nmodule.tx_easyconf.settings.support.phone = 111\"},\"newRecord\":{\"config\":\"module.tx_easyconf.settings.support.phone = (+41) 111 \\/ 222-333\"}}',0,'0400$1964af4f3ca67f60debb7c21a00c2809:35af6288617af54964e77af08c30949a'),(75,1670922264,2,'BE',1,0,1,'sys_template','{\"oldRecord\":{\"config\":\"module.tx_easyconf.settings.support.phone = (+41) 111 \\/ 222-333\"},\"newRecord\":{\"config\":\"# module.tx_easyconf.settings.support.phone = (+41) 111 \\/ 222-333\"}}',0,'0400$2e259e9247855ce43f3c4b81524234ee:35af6288617af54964e77af08c30949a');
/*!40000 ALTER TABLE `sys_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_lockedrecords`
--

DROP TABLE IF EXISTS `sys_lockedrecords`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_lockedrecords` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `userid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `record_table` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `record_uid` int(11) NOT NULL DEFAULT 0,
  `record_pid` int(11) NOT NULL DEFAULT 0,
  `username` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `feuserid` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `event` (`userid`,`tstamp`)
) ENGINE=InnoDB AUTO_INCREMENT=418 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_lockedrecords`
--

LOCK TABLES `sys_lockedrecords` WRITE;
/*!40000 ALTER TABLE `sys_lockedrecords` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_lockedrecords` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_news`
--

DROP TABLE IF EXISTS `sys_news`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_news` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `content` mediumtext COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_news`
--

LOCK TABLES `sys_news` WRITE;
/*!40000 ALTER TABLE `sys_news` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_news` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_note`
--

DROP TABLE IF EXISTS `sys_note`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_note` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `subject` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `message` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `personal` smallint(5) unsigned NOT NULL DEFAULT 0,
  `category` smallint(5) unsigned NOT NULL DEFAULT 0,
  `position` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_note`
--

LOCK TABLES `sys_note` WRITE;
/*!40000 ALTER TABLE `sys_note` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_note` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_refindex`
--

DROP TABLE IF EXISTS `sys_refindex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_refindex` (
  `hash` varchar(32) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `tablename` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `recuid` int(11) NOT NULL DEFAULT 0,
  `field` varchar(64) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `flexpointer` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `softref_key` varchar(30) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `softref_id` varchar(40) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `workspace` int(11) NOT NULL DEFAULT 0,
  `ref_table` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `ref_uid` int(11) NOT NULL DEFAULT 0,
  `ref_string` varchar(1024) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`hash`),
  KEY `lookup_rec` (`tablename`(100),`recuid`),
  KEY `lookup_uid` (`ref_table`(100),`ref_uid`),
  KEY `lookup_string` (`ref_string`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_refindex`
--

LOCK TABLES `sys_refindex` WRITE;
/*!40000 ALTER TABLE `sys_refindex` DISABLE KEYS */;
INSERT INTO `sys_refindex` VALUES ('201dc1e0bfcfe2f0da28f73af08e60c0','sys_file_metadata',2,'file','','','',0,0,'sys_file',2,''),('749b0771828793d3e3eba1372852a7a8','sys_file',2,'metadata','','','',0,0,'sys_file_metadata',2,''),('bb9038a252bcfeadc2e1e8a6b5266986','sys_file_metadata',1,'file','','','',0,0,'sys_file',1,''),('fe80a6589cac9798aa13ab5e0192cb56','sys_file',1,'metadata','','','',0,0,'sys_file_metadata',1,'');
/*!40000 ALTER TABLE `sys_refindex` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_registry`
--

DROP TABLE IF EXISTS `sys_registry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_registry` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `entry_namespace` varchar(128) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `entry_key` varchar(128) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `entry_value` mediumblob DEFAULT NULL,
  PRIMARY KEY (`uid`),
  UNIQUE KEY `entry_identifier` (`entry_namespace`,`entry_key`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_registry`
--

LOCK TABLES `sys_registry` WRITE;
/*!40000 ALTER TABLE `sys_registry` DISABLE KEYS */;
INSERT INTO `sys_registry` VALUES (4,'installUpdate','TYPO3\\CMS\\Install\\Updates\\FeeditExtractionUpdate','i:1;'),(5,'installUpdate','TYPO3\\CMS\\Install\\Updates\\TaskcenterExtractionUpdate','i:1;'),(6,'installUpdate','TYPO3\\CMS\\Install\\Updates\\SysActionExtractionUpdate','i:1;'),(7,'installUpdate','TYPO3\\CMS\\Install\\Updates\\SvgFilesSanitization','i:1;'),(9,'installUpdateRows','rowUpdatersDone','a:5:{i:0;s:69:\"TYPO3\\CMS\\Install\\Updates\\RowUpdater\\WorkspaceVersionRecordsMigration\";i:1;s:66:\"TYPO3\\CMS\\Install\\Updates\\RowUpdater\\L18nDiffsourceToJsonMigration\";i:2;s:77:\"TYPO3\\CMS\\Install\\Updates\\RowUpdater\\WorkspaceMovePlaceholderRemovalMigration\";i:3;s:76:\"TYPO3\\CMS\\Install\\Updates\\RowUpdater\\WorkspaceNewPlaceholderRemovalMigration\";i:4;s:69:\"TYPO3\\CMS\\Install\\Updates\\RowUpdater\\SysRedirectRootPageMoveMigration\";}'),(10,'installUpdate','TYPO3\\CMS\\Install\\Updates\\BackendUserLanguageMigration','i:1;'),(11,'core','formProtectionSessionToken:1','s:64:\"cbf4a02a3cd2ef3094cd3d414d74b092bca602bf907a220302bcf05b9f2c46a4\";'),(12,'core','sys_refindex_lastUpdate','i:1663385233;'),(14,'installUpdate','TYPO3\\CMS\\Install\\Updates\\SysLogSerializationUpdate','i:1;');
/*!40000 ALTER TABLE `sys_registry` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_template`
--

DROP TABLE IF EXISTS `sys_template`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_template` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `description` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `root` smallint(5) unsigned NOT NULL DEFAULT 0,
  `clear` smallint(5) unsigned NOT NULL DEFAULT 0,
  `include_static_file` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `constants` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `config` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `basedOn` tinytext COLLATE utf8_unicode_ci DEFAULT NULL,
  `includeStaticAfterBasedOn` smallint(5) unsigned NOT NULL DEFAULT 0,
  `static_file_mode` smallint(5) unsigned NOT NULL DEFAULT 0,
  `tx_impexp_origuid` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `roottemplate` (`deleted`,`hidden`,`root`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_template`
--

LOCK TABLES `sys_template` WRITE;
/*!40000 ALTER TABLE `sys_template` DISABLE KEYS */;
INSERT INTO `sys_template` VALUES (1,1,1670922264,1649334946,0,0,0,0,256,NULL,0,'NEW SITE',1,3,'EXT:bootstrap_package/Configuration/TypoScript,EXT:pizpalue/Configuration/TypoScript/Main','module.tx_easyconf.typoScriptConstantMapper.storage =\r\nmodule.tx_easyconf.typoScriptConstantMapper.importStatementHandling =\r\n\r\n# The following line has been added automatically by the extension easyconf\r\n@import \'fileadmin/easyconf/Configuration/TypoScript/EasyconfConstantsP1T1.typoscript\'','# module.tx_easyconf.settings.support.phone = (+41) 111 / 222-333','',0,0,0),(2,2,1649338787,1649338776,1,0,0,0,256,NULL,0,'+ext',0,0,NULL,NULL,NULL,'',0,0,0),(3,2,1650612910,1649338793,0,0,0,0,256,NULL,0,'+ext',0,0,NULL,'\r\n\r\n# The following line has been added automatically by the extension easyconf\r\n@import \'fileadmin/easyconf/Configuration/TypoScript/EasyconfConstantsP2T3.typoscript/\'',NULL,'',0,0,0),(4,4,1650612924,1649919244,0,0,0,0,256,NULL,0,'+ext',0,0,NULL,'',NULL,'',0,0,0),(5,5,1650612932,1649919348,0,0,0,0,256,NULL,0,'+ext',0,0,NULL,'',NULL,'',0,0,0);
/*!40000 ALTER TABLE `sys_template` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tt_content`
--

DROP TABLE IF EXISTS `tt_content`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tt_content` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `rowDescription` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `fe_group` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `editlock` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l18n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_source` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l18n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `CType` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `header` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `header_position` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `bodytext` mediumtext COLLATE utf8_unicode_ci DEFAULT NULL,
  `bullets_type` smallint(5) unsigned NOT NULL DEFAULT 0,
  `uploads_description` smallint(5) unsigned NOT NULL DEFAULT 0,
  `uploads_type` smallint(5) unsigned NOT NULL DEFAULT 0,
  `assets` int(10) unsigned NOT NULL DEFAULT 0,
  `image` int(10) unsigned NOT NULL DEFAULT 0,
  `imagewidth` int(10) unsigned NOT NULL DEFAULT 0,
  `imageorient` smallint(5) unsigned NOT NULL DEFAULT 0,
  `imagecols` smallint(5) unsigned NOT NULL DEFAULT 0,
  `imageborder` smallint(5) unsigned NOT NULL DEFAULT 0,
  `media` int(10) unsigned NOT NULL DEFAULT 0,
  `layout` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `frame_class` varchar(60) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'default',
  `cols` int(10) unsigned NOT NULL DEFAULT 0,
  `space_before_class` varchar(60) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `space_after_class` varchar(60) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `records` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `pages` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `colPos` int(10) unsigned NOT NULL DEFAULT 0,
  `subheader` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `header_link` varchar(1024) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `image_zoom` smallint(5) unsigned NOT NULL DEFAULT 0,
  `header_layout` varchar(30) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  `list_type` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `sectionIndex` smallint(5) unsigned NOT NULL DEFAULT 0,
  `linkToTop` smallint(5) unsigned NOT NULL DEFAULT 0,
  `file_collections` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `filelink_size` smallint(5) unsigned NOT NULL DEFAULT 0,
  `filelink_sorting` varchar(64) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `filelink_sorting_direction` varchar(4) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `target` varchar(30) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `date` int(11) NOT NULL DEFAULT 0,
  `recursive` smallint(5) unsigned NOT NULL DEFAULT 0,
  `imageheight` int(10) unsigned NOT NULL DEFAULT 0,
  `pi_flexform` mediumtext COLLATE utf8_unicode_ci DEFAULT NULL,
  `accessibility_title` varchar(30) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `accessibility_bypass` smallint(5) unsigned NOT NULL DEFAULT 0,
  `accessibility_bypass_text` varchar(30) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `category_field` varchar(64) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `table_class` varchar(60) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `table_caption` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `table_delimiter` smallint(5) unsigned NOT NULL DEFAULT 0,
  `table_enclosure` smallint(5) unsigned NOT NULL DEFAULT 0,
  `table_header_position` smallint(5) unsigned NOT NULL DEFAULT 0,
  `table_tfoot` smallint(5) unsigned NOT NULL DEFAULT 0,
  `categories` int(10) unsigned NOT NULL DEFAULT 0,
  `selected_categories` longtext COLLATE utf8_unicode_ci DEFAULT NULL,
  `tx_impexp_origuid` int(11) NOT NULL DEFAULT 0,
  `teaser` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `aspect_ratio` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '1.3333333333333',
  `items_per_page` int(10) unsigned DEFAULT 10,
  `readmore_label` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `quote_source` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `quote_link` varchar(1024) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `panel_class` varchar(60) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'default',
  `file_folder` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `icon` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `icon_set` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `icon_file` int(10) unsigned DEFAULT 0,
  `icon_position` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `icon_size` varchar(60) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'default',
  `icon_type` varchar(60) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'default',
  `icon_color` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `icon_background` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `external_media_source` varchar(1024) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `external_media_ratio` varchar(10) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `tx_bootstrappackage_card_group_item` int(10) unsigned DEFAULT 0,
  `tx_bootstrappackage_carousel_item` int(10) unsigned DEFAULT 0,
  `tx_bootstrappackage_accordion_item` int(10) unsigned DEFAULT 0,
  `tx_bootstrappackage_icon_group_item` int(10) unsigned DEFAULT 0,
  `tx_bootstrappackage_tab_item` int(10) unsigned DEFAULT 0,
  `tx_bootstrappackage_timeline_item` int(10) unsigned DEFAULT 0,
  `frame_layout` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'default',
  `background_color_class` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `background_image` int(10) unsigned DEFAULT 0,
  `background_image_options` mediumtext COLLATE utf8_unicode_ci DEFAULT NULL,
  `tx_pizpalue_header_class` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `tx_pizpalue_subheader_class` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `tx_pizpalue_layout_breakpoint` varchar(15) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `tx_pizpalue_classes` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `tx_pizpalue_style` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `tx_pizpalue_attributes` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `tx_pizpalue_animation` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `tx_pizpalue_image_variants` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'variants',
  `tx_pizpalue_background_image_variants` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'pageVariants',
  `tx_pizpalue_image_scaling` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `tx_pizpalue_image_aspect_ratio` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `tx_pizpalue_scroll_navigation_enable` smallint(6) NOT NULL DEFAULT 0,
  `tx_pizpalue_scroll_navigation_title` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `tx_pizpalue_scroll_navigation_position` int(10) unsigned NOT NULL DEFAULT 0,
  `frame_options` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `tx_pizpalue_inner_space_before_class` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `tx_pizpalue_inner_space_after_class` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `tx_pizpalue_inner_classes` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`sorting`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`),
  KEY `language` (`l18n_parent`,`sys_language_uid`),
  KEY `translation_source` (`l10n_source`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tt_content`
--

LOCK TABLES `tt_content` WRITE;
/*!40000 ALTER TABLE `tt_content` DISABLE KEYS */;
INSERT INTO `tt_content` VALUES (1,'',1,1649335052,1649335052,0,0,0,0,'',256,0,0,0,0,NULL,0,'',0,0,0,0,'header','easyconf dev site','center',NULL,0,0,0,0,0,0,0,1,0,0,'0','default',0,'','',NULL,NULL,0,'','',0,'1','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'','','',NULL,124,0,0,0,0,NULL,0,NULL,'1.3333333333333',10,'','','','default',NULL,'','',0,'','default','default','#FFFFFF','#333333','','',0,0,0,0,0,0,'default','primary',0,'<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"sDEF\">\n            <language index=\"lDEF\">\n                <field index=\"parallax\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"fade\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"filter\">\n                    <value index=\"vDEF\"></value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>','none','none','','','','','0','variants','pageVariants','xxl: 1.0,\nxl: 1.0,\nlg: 1.0,\nmd: 1.0,\nsm: 1.0,\nxs: 1.0','xxl: 0,\nxl: 0,\nlg: 0,\nmd: 0,\nsm: 0,\nxs: 0',0,'',0,'','','','');
/*!40000 ALTER TABLE `tt_content` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_bootstrappackage_accordion_item`
--

DROP TABLE IF EXISTS `tx_bootstrappackage_accordion_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_bootstrappackage_accordion_item` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `tt_content` int(10) unsigned DEFAULT 0,
  `header` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `bodytext` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `media` int(10) unsigned DEFAULT 0,
  `mediaorient` varchar(60) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'left',
  `imagecols` smallint(5) unsigned NOT NULL DEFAULT 1,
  `image_zoom` smallint(5) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_bootstrappackage_accordion_item`
--

LOCK TABLES `tx_bootstrappackage_accordion_item` WRITE;
/*!40000 ALTER TABLE `tx_bootstrappackage_accordion_item` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_bootstrappackage_accordion_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_bootstrappackage_card_group_item`
--

DROP TABLE IF EXISTS `tx_bootstrappackage_card_group_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_bootstrappackage_card_group_item` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `tt_content` int(10) unsigned DEFAULT 0,
  `header` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `subheader` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `image` int(11) NOT NULL DEFAULT 0,
  `bodytext` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `link` varchar(1024) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `link_title` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `link_icon_set` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `link_icon_identifier` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `link_icon` int(10) unsigned DEFAULT 0,
  `link_class` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_bootstrappackage_card_group_item`
--

LOCK TABLES `tx_bootstrappackage_card_group_item` WRITE;
/*!40000 ALTER TABLE `tx_bootstrappackage_card_group_item` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_bootstrappackage_card_group_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_bootstrappackage_carousel_item`
--

DROP TABLE IF EXISTS `tx_bootstrappackage_carousel_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_bootstrappackage_carousel_item` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `tt_content` int(10) unsigned DEFAULT 0,
  `item_type` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `layout` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `header` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `header_layout` smallint(5) unsigned NOT NULL DEFAULT 1,
  `header_position` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'center',
  `header_class` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `subheader` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `subheader_layout` smallint(5) unsigned NOT NULL DEFAULT 2,
  `subheader_class` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `nav_title` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `button_text` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `bodytext` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `image` int(10) unsigned DEFAULT 0,
  `link` varchar(1024) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `text_color` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `background_color` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `background_image` int(10) unsigned DEFAULT 0,
  `background_image_options` mediumtext COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_bootstrappackage_carousel_item`
--

LOCK TABLES `tx_bootstrappackage_carousel_item` WRITE;
/*!40000 ALTER TABLE `tx_bootstrappackage_carousel_item` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_bootstrappackage_carousel_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_bootstrappackage_icon_group_item`
--

DROP TABLE IF EXISTS `tx_bootstrappackage_icon_group_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_bootstrappackage_icon_group_item` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `tt_content` int(10) unsigned DEFAULT 0,
  `header` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `subheader` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `bodytext` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `link` varchar(1024) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `icon_set` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `icon_identifier` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `icon_file` int(10) unsigned DEFAULT 0,
  `tx_pizpalue_icon_color` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_bootstrappackage_icon_group_item`
--

LOCK TABLES `tx_bootstrappackage_icon_group_item` WRITE;
/*!40000 ALTER TABLE `tx_bootstrappackage_icon_group_item` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_bootstrappackage_icon_group_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_bootstrappackage_tab_item`
--

DROP TABLE IF EXISTS `tx_bootstrappackage_tab_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_bootstrappackage_tab_item` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `tt_content` int(10) unsigned DEFAULT 0,
  `header` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `bodytext` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `media` int(10) unsigned DEFAULT 0,
  `mediaorient` varchar(60) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'left',
  `imagecols` smallint(5) unsigned NOT NULL DEFAULT 1,
  `image_zoom` smallint(5) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_bootstrappackage_tab_item`
--

LOCK TABLES `tx_bootstrappackage_tab_item` WRITE;
/*!40000 ALTER TABLE `tx_bootstrappackage_tab_item` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_bootstrappackage_tab_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_bootstrappackage_timeline_item`
--

DROP TABLE IF EXISTS `tx_bootstrappackage_timeline_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_bootstrappackage_timeline_item` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `tt_content` int(10) unsigned DEFAULT 0,
  `date` datetime DEFAULT NULL,
  `header` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `bodytext` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `icon_set` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `icon_identifier` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `icon_file` int(10) unsigned DEFAULT 0,
  `image` int(10) unsigned DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_bootstrappackage_timeline_item`
--

LOCK TABLES `tx_bootstrappackage_timeline_item` WRITE;
/*!40000 ALTER TABLE `tx_bootstrappackage_timeline_item` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_bootstrappackage_timeline_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_easyconf_configuration`
--

DROP TABLE IF EXISTS `tx_easyconf_configuration`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_easyconf_configuration` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `fields` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `logo_file_reference` int(10) unsigned DEFAULT 0,
  `logo_file_inverted_reference` int(10) unsigned DEFAULT 0,
  `appicon_generator_archive` int(10) unsigned DEFAULT 0,
  `appicon_generator_text` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `menu_fast_items_first_content_uid` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `menu_fast_items_first_page_uid` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `menu_fast_items_second_content_uid` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `menu_fast_items_second_page_uid` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `menu_fast_items_third_content_uid` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `menu_fast_items_third_page_uid` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `menu_scroll_page_uid` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `social_channel_facebook` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `social_channel_twitter` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `social_channel_instagram` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `social_channel_github` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `social_channel_googleplus` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `social_channel_linkedin` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `social_channel_xing` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `social_channel_youtube` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `social_channel_vk` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `social_channel_vimeo` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `social_channel_rss` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `feature_contact_button_page_uid` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `cookie_content_href` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `social_channel_pinterest` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_easyconf_configuration`
--

LOCK TABLES `tx_easyconf_configuration` WRITE;
/*!40000 ALTER TABLE `tx_easyconf_configuration` DISABLE KEYS */;
INSERT INTO `tx_easyconf_configuration` VALUES (5,2,1649666926,1649666926,0,'{\"demo\":{\"showAllProperties\":\"1\"}}',0,0,0,NULL,'','','','','','','','','','','','','','','','','','','','',''),(9,1,1649668509,1649668509,0,'{\"demo\":{\"showAllProperties\":\"1\"},\"pizpalue\":{\"customer\":{\"url\":\"\",\"alternativeUrl\":\"\"},\"menu\":{\"main\":{\"enableSubpageDefinition\":\"0\",\"subpageStyle\":\"none\",\"subpageType\":\"\"}},\"social\":{\"facebook\":\"https:\\/\\/www.facebook.com\\/typo3\\/ - - Facebook\",\"twitter\":\"https:\\/\\/twitter.com\\/typo3 - - Twitter\",\"instagram\":\"https:\\/\\/www.instagram.com\\/ - - Instagram\",\"github\":\"https:\\/\\/github.com\\/buepro\\/typo3-pizpalue - - GitHub\",\"googleplus\":\"\",\"linkedin\":\"https:\\/\\/www.linkedin.com\\/ - - LinkedIn\",\"xing\":\"https:\\/\\/www.xing.com\\/ - - Xing\",\"youtube\":\"https:\\/\\/www.youtube.com\\/user\\/typo3 - - YouTube\",\"vk\":\"https:\\/\\/vk.com\\/ - - VK\",\"vimeo\":\"https:\\/\\/vimeo.com\\/ - - Vimeo\",\"rss\":\"https:\\/\\/www.srf.ch\\/allgemeines\\/rss-feeds-von-srf - - RSS\",\"pinterest\":\"https:\\/\\/www.pinterest.com\\/ - - Pinterest\"}}}',0,0,0,NULL,'','','','','','','','','','','','','','','','','','','','',''),(10,4,1649919258,1649919258,0,'',0,0,0,NULL,'','','','','','','','','','','','','','','','','','','','',''),(11,5,1649919356,1649919356,0,'',0,0,0,NULL,'','','','','','','','','','','','','','','','','','','','','');
/*!40000 ALTER TABLE `tx_easyconf_configuration` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_extensionmanager_domain_model_extension`
--

DROP TABLE IF EXISTS `tx_extensionmanager_domain_model_extension`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_extensionmanager_domain_model_extension` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `extension_key` varchar(60) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `repository` int(11) NOT NULL DEFAULT 1,
  `remote` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'ter',
  `version` varchar(15) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `alldownloadcounter` int(10) unsigned NOT NULL DEFAULT 0,
  `downloadcounter` int(10) unsigned NOT NULL DEFAULT 0,
  `title` varchar(150) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `description` mediumtext COLLATE utf8_unicode_ci DEFAULT NULL,
  `state` int(11) NOT NULL DEFAULT 0,
  `review_state` int(11) NOT NULL DEFAULT 0,
  `category` int(11) NOT NULL DEFAULT 0,
  `last_updated` int(11) NOT NULL DEFAULT 0,
  `serialized_dependencies` mediumtext COLLATE utf8_unicode_ci DEFAULT NULL,
  `author_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `author_email` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `ownerusername` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `md5hash` varchar(35) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `update_comment` mediumtext COLLATE utf8_unicode_ci DEFAULT NULL,
  `authorcompany` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `integer_version` int(11) NOT NULL DEFAULT 0,
  `current_version` int(11) NOT NULL DEFAULT 0,
  `lastreviewedversion` int(11) NOT NULL DEFAULT 0,
  `documentation_link` varchar(2048) COLLATE utf8_unicode_ci DEFAULT NULL,
  `distribution_image` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `distribution_welcome_image` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`uid`),
  UNIQUE KEY `versionextrepo` (`extension_key`,`version`,`remote`),
  KEY `index_extrepo` (`extension_key`,`remote`),
  KEY `index_versionrepo` (`integer_version`,`remote`,`extension_key`),
  KEY `index_currentversions` (`current_version`,`review_state`),
  KEY `parent` (`pid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_extensionmanager_domain_model_extension`
--

LOCK TABLES `tx_extensionmanager_domain_model_extension` WRITE;
/*!40000 ALTER TABLE `tx_extensionmanager_domain_model_extension` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_extensionmanager_domain_model_extension` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_impexp_presets`
--

DROP TABLE IF EXISTS `tx_impexp_presets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_impexp_presets` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `user_uid` int(10) unsigned NOT NULL DEFAULT 0,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `public` smallint(6) NOT NULL DEFAULT 0,
  `item_uid` int(11) NOT NULL DEFAULT 0,
  `preset_data` blob DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `lookup` (`item_uid`),
  KEY `parent` (`pid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_impexp_presets`
--

LOCK TABLES `tx_impexp_presets` WRITE;
/*!40000 ALTER TABLE `tx_impexp_presets` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_impexp_presets` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-12-13 20:52:44
